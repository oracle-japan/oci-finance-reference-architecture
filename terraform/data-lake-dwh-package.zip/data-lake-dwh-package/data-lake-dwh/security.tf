# 共通KMS Moduleで既存Vaultの再利用と暗号化キー作成を管理します。
module "kms" {
  source = "../modules/kms"

  enabled            = var.enable_kms
  compartment_id     = var.compartment_ocid
  existing_vault_id  = var.existing_vault_id
  vault_display_name = "${local.name_prefix}-vault"
  key_display_name   = "${local.name_prefix}-master-key"
  freeform_tags      = local.common_tags
}

# データ分析基盤の開発・運用担当者用Group
resource "oci_identity_domains_group" "data_platform_administrators" {
  count = var.enable_iam_resources ? 1 : 0

  display_name  = "${local.name_prefix}-dataplatformadmins"
  idcs_endpoint = local.iam_domain.url
  schemas       = ["urn:ietf:params:scim:schemas:core:2.0:Group"]
}

# normalized、analyticsデータの分析担当者用Group
resource "oci_identity_domains_group" "data_analysts" {
  count = var.enable_iam_resources ? 1 : 0

  display_name  = "${local.name_prefix}-dataanalysts"
  idcs_endpoint = local.iam_domain.url
  schemas       = ["urn:ietf:params:scim:schemas:core:2.0:Group"]
}

# Data CatalogがObject Storageを読み取るためのリソース・プリンシパル
resource "oci_identity_domains_dynamic_resource_group" "data_catalog" {
  count = var.enable_iam_resources ? 1 : 0

  display_name  = "${local.name_prefix}-data-catalog-drg"
  description   = "Object Storage参照用Data Catalogリソース・プリンシパル"
  idcs_endpoint = local.iam_domain.url
  matching_rule = "ALL {resource.type = 'datacatalog', resource.compartment.id = '${var.compartment_ocid}'}"
  schemas       = ["urn:ietf:params:scim:schemas:oracle:idcs:DynamicResourceGroup"]
}

# GroupとDynamic GroupはOCI OCIDで参照します。
resource "oci_identity_policy" "service_access" {
  count = var.enable_iam_resources ? 1 : 0

  provider = oci.home

  compartment_id = var.compartment_ocid
  name           = "${replace(local.name_prefix, "-", "_")}_runtime_policy"
  description    = "データレイクの運用者、分析者およびサービス用IAM Policy"
  freeform_tags  = local.common_tags

  statements = concat(
    [
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage autonomous-database-family in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage log-groups in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage log-content in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to read buckets in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage objects in compartment id ${var.compartment_ocid} where any {target.bucket.name='${local.object_storage_buckets.landing.name}', target.bucket.name='${local.object_storage_buckets.raw.name}', target.bucket.name='${local.object_storage_buckets.normalized.name}'}",
      "Allow group id ${oci_identity_domains_group.data_analysts[0].ocid} to read autonomous-database-family in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_analysts[0].ocid} to read buckets in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_analysts[0].ocid} to read objects in compartment id ${var.compartment_ocid} where any {target.bucket.name='${local.object_storage_buckets.normalized.name}', target.bucket.name='${local.object_storage_buckets.analytics.name}'}"
    ],
    [
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage dis-family in compartment id ${var.compartment_ocid}",
      "Allow any-user to {DIS_WORKSPACE_OBJECT_CREATE} in compartment id ${var.compartment_ocid} where all {request.service.name='dataintegration', request.principal.type='service'}",
      "Allow any-user to use buckets in compartment id ${var.compartment_ocid} where all {request.principal.type='disworkspace'}",
      "Allow any-user to manage objects in compartment id ${var.compartment_ocid} where all {request.principal.type='disworkspace'}"
    ],
    [
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage data-catalog-family in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_analysts[0].ocid} to read data-catalog-family in compartment id ${var.compartment_ocid}",
      "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.data_catalog[0].ocid} to read object-family in compartment id ${var.compartment_ocid}"
    ],
    nonsensitive(var.analytics_idcs_access_token != "") ? [
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage analytics-instances in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_platform_administrators[0].ocid} to manage analytics-instance-work-requests in compartment id ${var.compartment_ocid}",
      "Allow group id ${oci_identity_domains_group.data_analysts[0].ocid} to use analytics-instances in compartment id ${var.compartment_ocid}"
    ] : [],
    var.enable_kms ? [
      "Allow service objectstorage-${var.region} to use keys in compartment id ${var.compartment_ocid}"
    ] : []
  )
}
