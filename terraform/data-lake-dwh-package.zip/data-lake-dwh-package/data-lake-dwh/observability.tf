# 共通Logging ModuleにObject Storageのサービス・ログ設定を渡します。
module "logging" {
  source = "../modules/logging"

  compartment_id        = var.compartment_ocid
  log_group_name        = "${local.name_prefix}-logs"
  log_group_description = "金融データレイクのサービス・ログ"
  freeform_tags          = local.common_tags
  service_logs           = merge(
    {
      for layer in keys(local.object_storage_buckets) :
      "object_storage_${layer}_read" => {
        display_name  = "${local.name_prefix}-${layer}-object-storage-read-log"
        service       = "objectstorage"
        category      = "read"
        resource_id   = module.object_storage.bucket_names[layer]
      }
    },
    {
      for layer in keys(local.object_storage_buckets) :
      "object_storage_${layer}_write" => {
        display_name  = "${local.name_prefix}-${layer}-object-storage-write-log"
        service       = "objectstorage"
        category      = "write"
        resource_id   = module.object_storage.bucket_names[layer]
      }
    }
  )

  depends_on = [oci_identity_policy.service_access]
}

# Monitoringは各OCIサービスが提供する標準メトリックを使用します。
