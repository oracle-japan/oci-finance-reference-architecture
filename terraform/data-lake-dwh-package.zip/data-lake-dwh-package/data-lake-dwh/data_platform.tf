# 全データ層の処理を集約するWorkspace
resource "oci_dataintegration_workspace" "data_processing" {
  compartment_id            = var.compartment_ocid
  display_name              = "${local.name_prefix}-workspace"
  description               = "landing、raw、normalized、analyticsデータ層のData Integration Workspace"
  is_private_network_enabled = false
  freeform_tags             = local.common_tags

  depends_on = [oci_identity_policy.service_access]
}

# Object Storageのメタデータを集約するDataCatalog
resource "oci_datacatalog_catalog" "financial_data" {
  compartment_id = var.compartment_ocid
  display_name   = "${local.name_prefix}-catalog"
  freeform_tags  = local.common_tags

  depends_on = [oci_identity_policy.service_access]
}

# DataCatalogが提供するObject Storage用の型キーを取得します。
data "oci_datacatalog_catalog_types" "object_storage_data_asset" {
  catalog_id    = oci_datacatalog_catalog.financial_data.id
  type_category = "dataAsset"
  name          = "Oracle Object Storage"
  state         = "ACTIVE"
}

# 4 データ層を含むObject Storage NamespaceをData Assetとして登録します。
resource "oci_datacatalog_data_asset" "object_storage" {
  catalog_id   = oci_datacatalog_catalog.financial_data.id
  display_name = "${local.name_prefix}-object-storage"
  description  = "landing、raw、normalized、analyticsバケットのObject Storage Data Asset"
  type_key     = data.oci_datacatalog_catalog_types.object_storage_data_asset.type_collection[0].items[0].key
  properties = {
    "default.url"       = "https://swiftobjectstorage.${var.region}.oraclecloud.com"
    "default.namespace" = module.object_storage.namespace
  }
}

# 共通Oracle Analytics Cloud Moduleでデータ分析環境を作成します。
module "analytics_cloud" {
  source = "../modules/analytics-cloud"

  enabled           = nonsensitive(var.analytics_idcs_access_token != "")
  compartment_id    = var.compartment_ocid
  name              = "${local.name_prefix}-analytics"
  description       = "金融データレイク分析環境"
  idcs_access_token = var.analytics_idcs_access_token
  freeform_tags     = local.common_tags
}
