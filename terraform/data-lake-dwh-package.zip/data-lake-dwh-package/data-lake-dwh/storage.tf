# 共通Object Storage Moduleで 4 データ層のBucketを作成します。
module "object_storage" {
  source = "../modules/object-storage"

  compartment_id     = var.compartment_ocid
  default_kms_key_id = module.kms.key_id
  buckets            = local.object_storage_buckets

  depends_on = [oci_identity_policy.service_access]
}
