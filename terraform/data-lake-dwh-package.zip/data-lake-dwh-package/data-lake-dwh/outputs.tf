output "iam_domain" {
  description = "選択したIAM Domain。"
  value = {
    id           = local.iam_domain.id
    display_name = local.iam_domain.display_name
    url          = local.iam_domain.url
  }
}

output "bucket_names" {
  description = "4 データ層のバケット名。"
  value       = module.object_storage.bucket_names
}

output "data_integration_workspace_id" {
  description = "Data Integration Workspace OCID。"
  value       = oci_dataintegration_workspace.data_processing.id
}

output "data_catalog_id" {
  description = "Data Catalog OCID。"
  value       = oci_datacatalog_catalog.financial_data.id
}

output "object_storage_data_asset_key" {
  description = "Object Storage Data Assetの一意キー。"
  value       = oci_datacatalog_data_asset.object_storage.key
}

output "iam_group_ids" {
  description = "データ分析基盤管理者およびデータ分析者Group OCID。"
  value = {
    data_platform_administrators = try(oci_identity_domains_group.data_platform_administrators[0].ocid, null)
    data_analysts                = try(oci_identity_domains_group.data_analysts[0].ocid, null)
  }
}

output "lakehouse_id" {
  description = "Autonomous AI Lakehouse OCID。"
  value       = try(module.autonomous_database.database_ids["lakehouse"], null)
}

output "analytics_instance_id" {
  description = "Oracle Analytics Cloud OCID。"
  value       = module.analytics_cloud.instance_id
}

output "kms_key_id" {
  description = "Object Storage暗号化キーOCID。"
  value       = module.kms.key_id
}

output "kms_vault_id" {
  description = "再利用または新規作成したVault OCID。"
  value       = module.kms.vault_id
}

output "log_group_id" {
  description = "データレイク専用Log Group OCID。"
  value       = module.logging.log_group_id
}

output "service_log_ids" {
  description = "Object Storageのサービス・ログOCID。"
  value = {
    object_storage_read = {
      for layer in keys(local.object_storage_buckets) :
      layer => module.logging.log_ids["object_storage_${layer}_read"]
    }
    object_storage_write = {
      for layer in keys(local.object_storage_buckets) :
      layer => module.logging.log_ids["object_storage_${layer}_write"]
    }
  }
}

output "deployment_notes" {
  description = "未作成リソースと運用上の注意。"
  value = compact([
    nonsensitive(var.analytics_idcs_access_token == "") ? "analytics_idcs_access_tokenが空のためOracle Analytics Cloudは未作成です。" : "",
    "Data Assetのハーベスト前にResource Principal ConnectionをData Catalogで作成してください。",
    nonsensitive(var.analytics_idcs_access_token != "") ? "データ分析者のダッシュボード作成権限はAnalytics Cloudのアプリケーション・ロールで追加設定してください。" : ""
  ])
}
