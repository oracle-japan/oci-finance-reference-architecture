# 基本設定
variable "tenancy_ocid" {
  description = "テナンシーOCID。Resource Managerにより自動設定されます。"
  type        = string
}

variable "compartment_ocid" {
  description = "リソースを作成するコンパートメントOCID。"
  type        = string
}

variable "region" {
  description = "リソースのデプロイ先として使用するOCIリージョンを指定します。"
  type        = string
}

variable "iam_domain_name" {
  description = "使用するIAMアイデンティティ・ドメイン表示名。"
  type        = string
  default     = "Default"
}

variable "project_name" {
  description = "リソース名に使用するプロジェクト名。"
  type        = string
  default     = "financial-data-lake"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,29}$", var.project_name))
    error_message = "英小文字で始まる 3～30 文字の英小文字、数字、ハイフンで指定してください。"
  }
}

variable "freeform_tags" {
  description = "全リソースに追加するフリーフォーム・タグ。"
  type        = map(string)
  default     = {}
}

variable "analytics_idcs_access_token" {
  description = "Oracle Analytics Cloud作成用IDCSアクセス・トークン。"
  type        = string
  sensitive   = true
  default     = ""
}

# セキュリティ
variable "enable_iam_resources" {
  description = "データ分析基盤管理者、データ分析者Groupと必要なIAM Policyを作成します。"
  type        = bool
  default     = true
}

variable "enable_kms" {
  description = "Object Storage暗号化用VaultとKeyを使用します。"
  type        = bool
  default     = true
}

variable "existing_vault_id" {
  description = "再利用する既存Vault OCID。空の場合は新しいVaultを作成します。"
  type        = string
  default     = ""

  validation {
    condition     = var.existing_vault_id == "" || startswith(var.existing_vault_id, "ocid1.vault.")
    error_message = "existing_vault_idにはVault OCID、または空文字を指定してください。"
  }
}
