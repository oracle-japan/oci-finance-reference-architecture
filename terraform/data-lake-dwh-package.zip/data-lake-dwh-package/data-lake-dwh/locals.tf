locals {
  name_prefix             = var.project_name
  iam_domain              = try(data.oci_identity_domains.selected.domains[0], null)
  oci_region_names_by_key = { for region in data.oci_identity_regions.available.regions : region.key => region.name }
  home_region             = lookup(local.oci_region_names_by_key, data.oci_identity_tenancy.current.home_region_key)

  common_tags = merge(var.freeform_tags, {
    Project      = var.project_name
    Architecture = "DataLake"
    ManagedBy    = "Resource Manager"
  })

  data_layers = toset(["landing", "raw", "normalized", "analytics"])

  object_storage_buckets = {
    for layer in local.data_layers : layer => {
      name                  = "${local.name_prefix}-${layer}"
      object_events_enabled = true
      freeform_tags         = merge(local.common_tags, { DataLayer = layer })
    }
  }

  autonomous_databases = {
    lakehouse = {
      db_name       = "FINLAKE"
      display_name  = "${local.name_prefix}-lakehouse"
      db_workload   = "LH"
      freeform_tags = local.common_tags
    }
  }
}
