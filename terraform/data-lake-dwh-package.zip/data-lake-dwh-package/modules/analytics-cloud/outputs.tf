output "instance_id" {
  description = "Oracle Analytics Cloud OCID。未作成の場合はnull。"
  value       = try(oci_analytics_analytics_instance.this[0].id, null)
}
