variable "enabled" {
  description = "Oracle Analytics Cloudを作成するかどうか。"
  type        = bool
  default     = true
}

variable "compartment_id" {
  description = "Oracle Analytics Cloudを作成するコンパートメントOCID。"
  type        = string
}

variable "name" {
  description = "Oracle Analytics Cloudの名前。"
  type        = string

  validation {
    condition     = can(regex("^[A-Za-z][A-Za-z0-9_-]{0,29}$", var.name))
    error_message = "nameは英字で始まる30文字以内の英数字、ハイフン、アンダースコアで指定してください。"
  }
}

variable "description" {
  description = "Oracle Analytics Cloudの説明。"
  type        = string
  default     = null
}

variable "idcs_access_token" {
  description = "Oracle Analytics Cloud作成用IDCSアクセス・トークン。"
  type        = string
  sensitive   = true
}

variable "feature_set" {
  description = "Oracle Analytics Cloudの機能セット。"
  type        = string
  default     = "ENTERPRISE_ANALYTICS"

  validation {
    condition     = contains(["ENTERPRISE_ANALYTICS", "SELF_SERVICE_ANALYTICS"], var.feature_set)
    error_message = "feature_setはENTERPRISE_ANALYTICSまたはSELF_SERVICE_ANALYTICSを指定してください。"
  }
}

variable "license_type" {
  description = "Oracle Analytics Cloudのライセンス種別。"
  type        = string
  default     = "LICENSE_INCLUDED"

  validation {
    condition     = contains(["LICENSE_INCLUDED", "BRING_YOUR_OWN_LICENSE"], var.license_type)
    error_message = "license_typeはLICENSE_INCLUDEDまたはBRING_YOUR_OWN_LICENSEを指定してください。"
  }
}

variable "capacity_type" {
  description = "Oracle Analytics Cloudの容量単位。"
  type        = string
  default     = "OLPU_COUNT"

  validation {
    condition     = var.capacity_type == "OLPU_COUNT"
    error_message = "capacity_typeにはOLPU_COUNTを指定してください。"
  }
}

variable "capacity_value" {
  description = "Oracle Analytics Cloudの容量値。"
  type        = number
  default     = 1

  validation {
    condition     = var.capacity_value > 0
    error_message = "capacity_valueは0より大きい値を指定してください。"
  }
}

variable "network_endpoint_type" {
  description = "Oracle Analytics Cloudのネットワーク・エンドポイント種別。"
  type        = string
  default     = "PUBLIC"

  validation {
    condition     = contains(["PUBLIC", "PRIVATE"], var.network_endpoint_type)
    error_message = "network_endpoint_typeはPUBLICまたはPRIVATEを指定してください。"
  }
}

variable "freeform_tags" {
  description = "Oracle Analytics Cloudに設定するフリーフォーム・タグ。"
  type        = map(string)
  default     = {}
}
