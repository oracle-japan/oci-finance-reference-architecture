# ルート・モジュールから渡された設定でOracle Analytics Cloudを作成します。
resource "oci_analytics_analytics_instance" "this" {
  count = var.enabled ? 1 : 0

  compartment_id    = var.compartment_id
  name              = var.name
  description       = var.description
  feature_set       = var.feature_set
  license_type      = var.license_type
  idcs_access_token = var.idcs_access_token
  freeform_tags     = var.freeform_tags

  capacity {
    capacity_type  = var.capacity_type
    capacity_value = var.capacity_value
  }

  network_endpoint_details {
    network_endpoint_type = var.network_endpoint_type
  }
}
