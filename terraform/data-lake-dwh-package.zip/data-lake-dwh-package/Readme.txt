# OCI Data Lake / DWH Terraform

## Terraform サンプルコードについて

本ディレクトリに含まれるTerraformコードは、本リファレンスアーキテクチャで示す構成や考え方を理解するための参考実装（サンプルコード）です。

本コードは、特定のお客様環境や本番環境へのそのままの適用を目的として設計されたものではありません。また、本コードのみを根拠としてシステム設計を行うことを意図したものでもありません。

実際のシステムを設計・構築する際には、対象環境の要件に応じて、以下を含む各種要件を個別に検討してください。

* セキュリティおよびアクセス制御
* 可用性、冗長性および災害対策
* 性能およびスケーラビリティ
* ネットワーク構成
* 運用、監視およびバックアップ
* コストおよびリソースサイジング
* 組織のセキュリティポリシー、ガバナンスおよびコンプライアンス要件
* 利用するサービス、Terraform Providerおよび各種依存コンポーネントのバージョン

本コードを利用する場合は、内容を十分に確認し、利用環境に合わせて必要な変更を行ったうえで、事前に適切なレビューおよび検証を実施してください。

## Disclaimer

本資料およびTerraformコードは、情報提供および参考目的で提供されるものです。特定のシステム構成、設計、性能、セキュリティ、可用性または運用結果を保証するものではありません。

実際のシステムへの適用可否および構成については、各利用者の責任において、要件、環境、適用される規則・ポリシー等を考慮したうえで判断してください。

また、クラウドサービス、Terraform Providerその他関連する製品・サービスの仕様は変更される場合があります。利用時には、各製品・サービスの最新の公式ドキュメントおよびサポートされる構成を確認してください。

## 本コードについて

OCI 上に金融機関向けのデータレイクおよびデータ分析基盤を構築する Terraform 構成です。

この README では、Terraform の構造、設定の流れ、事前に定義する変数、`terraform.tfvars` で編集する値について説明します。

## 構造

```text
data-lake-dwh-package/
├── modules/
│   ├── analytics-cloud/
│   ├── autonomous-database/
│   ├── kms/
│   ├── logging/
│   ├── network/
│   └── object-storage/
└── data-lake-dwh/
    ├── data.tf
    ├── data_platform.tf
    ├── database.tf
    ├── locals.tf
    ├── observability.tf
    ├── outputs.tf
    ├── provider.tf
    ├── schema.yaml
    ├── security.tf
    ├── storage.tf
    ├── terraform.tfvars.example
    ├── variables.tf
    └── versions.tf
```

Terraform の実行ディレクトリは `data-lake-dwh/` です。

主な構成は以下です。

* `data_platform.tf`
  Data Integration Workspace、Data Catalog、Object Storage Data Asset、Oracle Analytics Cloud を作成します。
* `database.tf`
  Autonomous AI Lakehouse を作成します。
* `storage.tf`
  Landing、Raw、Normalized、Analytics の4つの Object Storage Bucket を作成します。
* `security.tf`
  IAM Group、Dynamic Resource Group、IAM Policy、KMS / Vault を設定します。
* `observability.tf`
  Object Storage の Logging を設定します。

## 設定の流れ

### 1. サンプル設定をコピー

```bash
cd data-lake-dwh-package/data-lake-dwh
cp terraform.tfvars.example terraform.tfvars
```

### 2. `terraform.tfvars` を編集

OCI 環境に合わせて基本設定を変更します。

```hcl
tenancy_ocid     = "ocid1.tenancy.oc1..xxxxxxxx"
compartment_ocid = "ocid1.compartment.oc1..xxxxxxxx"
region           = "ap-osaka-1"
iam_domain_name  = "Default"

project_name = "financial-data-lake"
```

必要に応じて Oracle Analytics Cloud、IAM、KMS を設定します。

```hcl
analytics_idcs_access_token = ""

enable_iam_resources = true

enable_kms        = true
existing_vault_id = ""
```

### 3. Terraform を初期化

```bash
terraform init
```

### 4. 設定を確認

```bash
terraform validate
terraform plan
```

### 5. リソースを作成

```bash
terraform apply
```

## 事前に定義する変数

### 必須

| 変数                 | 説明                     | 例                             |
| ------------------ | ---------------------- | ----------------------------- |
| `tenancy_ocid`     | OCI Tenancy の OCID     | `ocid1.tenancy.oc1..xxxx`     |
| `compartment_ocid` | 作成先 Compartment の OCID | `ocid1.compartment.oc1..xxxx` |
| `region`           | デプロイ先 Region           | `ap-osaka-1`                  |

### 基本設定

| 変数                | 説明                    | デフォルト / 例             |
| ----------------- | --------------------- | --------------------- |
| `iam_domain_name` | IAM Identity Domain 名 | `Default`             |
| `project_name`    | リソース名の Prefix         | `financial-data-lake` |
| `freeform_tags`   | 追加する Free-form Tags   | `{}`                  |

### Oracle Analytics Cloud

Oracle Analytics Cloud を作成する場合、IDCS Access Token を指定します。

```hcl
analytics_idcs_access_token = "YOUR_IDCS_ACCESS_TOKEN"
```

Oracle Analytics Cloud を作成しない場合は空のままにします。

```hcl
analytics_idcs_access_token = ""
```

### IAM

Terraform で IAM Group、Dynamic Resource Group、Policy を作成する場合:

```hcl
enable_iam_resources = true
iam_domain_name      = "Default"
```

既存の IAM 設定を利用する場合:

```hcl
enable_iam_resources = false
```

### KMS

Vault / KMS Key を新規作成する場合:

```hcl
enable_kms        = true
existing_vault_id = ""
```

既存 Vault を利用する場合:

```hcl
enable_kms        = true
existing_vault_id = "ocid1.vault.oc1.ap-osaka-1.xxxxxxxx"
```

KMS を使用しない場合:

```hcl
enable_kms = false
```

## 編集するサンプル値

`terraform.tfvars.example` をコピー後、以下を環境に合わせて編集してください。

```hcl
tenancy_ocid     = "YOUR_TENANCY_OCID"
compartment_ocid = "YOUR_COMPARTMENT_OCID"
region           = "ap-osaka-1"
iam_domain_name  = "Default"

project_name = "financial-data-lake"

analytics_idcs_access_token = ""

enable_iam_resources = true

enable_kms        = true
existing_vault_id = ""
```

最低限、環境に合わせて確認・変更する値は以下です。

```hcl
tenancy_ocid
compartment_ocid
region
```

Oracle Analytics Cloud を作成する場合は、以下も設定します。

```hcl
analytics_idcs_access_token
```

既存の Vault を利用する場合は、以下も設定します。

```hcl
existing_vault_id
```

Resource Manager を利用する場合、`tenancy_ocid` は Resource Manager により自動設定されます。

`analytics_idcs_access_token` が空の場合、Oracle Analytics Cloud は作成されません。
