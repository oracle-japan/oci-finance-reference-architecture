output "database_ids" {
  description = "論理キーごとのAutonomous AI Database OCID。"
  value       = { for key, database in oci_database_autonomous_database.databases : key => database.id }
}

output "database_names" {
  description = "論理キーごとのAutonomous AI Database名。"
  value       = { for key, database in oci_database_autonomous_database.databases : key => database.db_name }
}
