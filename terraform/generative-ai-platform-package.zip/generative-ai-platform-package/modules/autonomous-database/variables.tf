variable "compartment_id" {
  description = "Autonomous AI Databaseを作成するコンパートメントOCID。"
  type        = string
}

variable "databases" {
  description = "論理キーごとのAutonomous AI Database設定。"
  type = map(object({
    db_name                             = string
    display_name                        = string
    db_workload                         = string
    # 共通値は省略可能とし、構成ごとに差がある場合だけルート・モジュールから上書きします。
    compute_model                       = optional(string, "ECPU")
    compute_count                       = optional(number, 2)
    data_storage_size_in_tbs            = optional(number, 1)
    license_model                       = optional(string, "LICENSE_INCLUDED")
    is_auto_scaling_enabled             = optional(bool, true)
    is_auto_scaling_for_storage_enabled = optional(bool, true)
    is_mtls_connection_required         = optional(bool, true)
    subnet_id                           = optional(string)
    private_endpoint_label              = optional(string)
    defined_tags                        = optional(map(string))
    freeform_tags                       = optional(map(string), {})
  }))
  default = {}

  validation {
    condition = alltrue([
      for database in values(var.databases) :
      can(regex("^[A-Za-z][A-Za-z0-9]{0,29}$", database.db_name))
    ])
    error_message = "db_nameは英字で始まる 30 文字以内の英数字で指定してください。"
  }

  validation {
    condition = alltrue([
      for database in values(var.databases) :
      contains(["OLTP", "LH", "AJD", "APEX"], database.db_workload)
    ])
    error_message = "db_workloadはOLTP、LH、AJD、APEXのいずれかを指定してください。"
  }

  validation {
    condition = alltrue([
      for database in values(var.databases) :
      contains(["ECPU", "OCPU"], database.compute_model)
    ])
    error_message = "compute_modelはECPUまたはOCPUを指定してください。"
  }

  validation {
    condition = alltrue([
      for database in values(var.databases) :
      database.compute_count > 0 && database.data_storage_size_in_tbs > 0
    ])
    error_message = "compute_countとdata_storage_size_in_tbsは 0 より大きい値を指定してください。"
  }

  validation {
    condition = alltrue([
      for database in values(var.databases) :
      contains(["LICENSE_INCLUDED", "BRING_YOUR_OWN_LICENSE"], database.license_model)
    ])
    error_message = "license_modelはLICENSE_INCLUDEDまたはBRING_YOUR_OWN_LICENSEを指定してください。"
  }
}
