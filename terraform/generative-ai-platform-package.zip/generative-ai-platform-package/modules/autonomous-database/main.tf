# Autonomous AI Databaseの管理者パスワードを自動生成します。
resource "random_password" "autonomous_database_admin_password" {
  length      = 16
  min_numeric = 1
  min_lower   = 1
  min_upper   = 1
  min_special = 1
}

# ルート・モジュールから渡された用途別Autonomous AI Databaseを作成します。
resource "oci_database_autonomous_database" "databases" {
  for_each = var.databases

  compartment_id                      = var.compartment_id
  admin_password                      = random_password.autonomous_database_admin_password.result
  db_name                             = each.value.db_name
  display_name                        = each.value.display_name
  db_workload                         = each.value.db_workload
  compute_model                       = each.value.compute_model
  compute_count                       = each.value.compute_count
  data_storage_size_in_tbs            = each.value.data_storage_size_in_tbs
  license_model                       = each.value.license_model
  is_auto_scaling_enabled             = each.value.is_auto_scaling_enabled
  is_auto_scaling_for_storage_enabled = each.value.is_auto_scaling_for_storage_enabled
  is_mtls_connection_required         = each.value.is_mtls_connection_required
  subnet_id                           = each.value.subnet_id
  private_endpoint_label              = each.value.private_endpoint_label
  defined_tags                        = each.value.defined_tags
  freeform_tags                       = each.value.freeform_tags
}
