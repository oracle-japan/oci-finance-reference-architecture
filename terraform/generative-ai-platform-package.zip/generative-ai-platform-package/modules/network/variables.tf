variable "compartment_id" {
  description = "ネットワーク・リソースを作成するコンパートメントOCID。"
  type        = string
}

variable "vcn" {
  description = "VCNの設定。"
  type = object({
    cidr_blocks   = list(string)
    display_name  = string
    dns_label     = string
    freeform_tags = map(string)
  })
}

variable "internet_gateway" {
  description = "Internet Gatewayの設定。nullの場合は作成しません。"
  type = object({
    display_name  = string
    enabled       = optional(bool, true)
    freeform_tags = map(string)
  })
  default  = null
  nullable = true
}

variable "nat_gateway" {
  description = "NAT Gatewayの設定。nullの場合は作成しません。"
  type = object({
    display_name  = string
    freeform_tags = map(string)
  })
  default  = null
  nullable = true
}

variable "service_gateway" {
  description = "Service Gatewayの設定。nullの場合は作成しません。"
  type = object({
    display_name  = string
    freeform_tags = map(string)
  })
  default  = null
  nullable = true
}

variable "route_tables" {
  description = "Route Tableとルールの設定。network_entity_keyでGatewayを参照します。"
  type = map(object({
    display_name  = string
    freeform_tags = map(string)
    route_rules = list(object({
      destination        = optional(string)
      destination_type   = string
      network_entity_key = string
    }))
  }))
  default = {}
}

variable "security_lists" {
  description = "Security ListとIngress/Egressルールの設定。"
  type = map(object({
    display_name  = string
    freeform_tags = map(string)
    ingress_rules = list(object({
      protocol    = string
      source      = string
      source_type = optional(string, "CIDR_BLOCK")
      description = optional(string)
      stateless   = optional(bool, false)
      tcp_min     = optional(number)
      tcp_max     = optional(number)
    }))
    egress_rules = list(object({
      protocol         = string
      destination      = string
      destination_type = optional(string, "CIDR_BLOCK")
      description      = optional(string)
      stateless        = optional(bool, false)
      tcp_min          = optional(number)
      tcp_max          = optional(number)
    }))
  }))
  default = {}
}

variable "subnets" {
  description = "公開／非公開サブネットの共通設定。Route TableとSecurity Listは論理キーで参照します。"
  type = map(object({
    cidr_block         = string
    display_name       = string
    dns_label          = string
    is_public          = bool
    route_table_key    = string
    security_list_keys = list(string)
    freeform_tags      = map(string)
  }))
  default = {}
}
