output "vcn_id" {
  description = "VCNのOCID。"
  value       = oci_core_vcn.network.id
}

output "gateway_ids" {
  description = "論理キーごとのGateway OCID。未作成のGatewayはnull。"
  value       = local.gateway_ids
}

output "subnet_ids" {
  description = "論理キーごとのSubnet OCID。"
  value       = { for key, subnet in oci_core_subnet.subnets : key => subnet.id }
}

output "route_table_ids" {
  description = "論理キーごとのRoute Table OCID。"
  value       = { for key, route_table in oci_core_route_table.route_tables : key => route_table.id }
}

output "security_list_ids" {
  description = "論理キーごとのSecurity List OCID。"
  value       = { for key, security_list in oci_core_security_list.security_lists : key => security_list.id }
}
