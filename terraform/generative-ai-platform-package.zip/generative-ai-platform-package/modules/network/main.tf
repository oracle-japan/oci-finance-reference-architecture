# Oracle Services Networkのリージョン固有CIDRを取得します。
data "oci_core_services" "oracle_services" {
  filter {
    name   = "name"
    values = ["All .* Services In Oracle Services Network"]
    regex  = true
  }
}

resource "oci_core_vcn" "network" {
  compartment_id = var.compartment_id
  cidr_blocks     = var.vcn.cidr_blocks
  display_name    = var.vcn.display_name
  dns_label       = var.vcn.dns_label
  freeform_tags   = var.vcn.freeform_tags
}

resource "oci_core_internet_gateway" "internet_access" {
  count = var.internet_gateway == null ? 0 : 1

  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.network.id
  display_name   = try(var.internet_gateway.display_name, null)
  enabled        = try(var.internet_gateway.enabled, true)
  freeform_tags  = try(var.internet_gateway.freeform_tags, {})
}

resource "oci_core_nat_gateway" "outbound_internet" {
  count = var.nat_gateway == null ? 0 : 1

  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.network.id
  display_name   = try(var.nat_gateway.display_name, null)
  freeform_tags  = try(var.nat_gateway.freeform_tags, {})
}

resource "oci_core_service_gateway" "oracle_services" {
  count = var.service_gateway == null ? 0 : 1

  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.network.id
  display_name   = try(var.service_gateway.display_name, null)
  freeform_tags  = try(var.service_gateway.freeform_tags, {})

  services {
    service_id = data.oci_core_services.oracle_services.services[0].id
  }
}

locals {
  gateway_ids = {
    internet_gateway = try(oci_core_internet_gateway.internet_access[0].id, null)
    nat_gateway      = try(oci_core_nat_gateway.outbound_internet[0].id, null)
    service_gateway  = try(oci_core_service_gateway.oracle_services[0].id, null)
  }
}

resource "oci_core_route_table" "route_tables" {
  for_each = var.route_tables

  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.network.id
  display_name   = each.value.display_name
  freeform_tags  = each.value.freeform_tags

  dynamic "route_rules" {
    for_each = each.value.route_rules

    content {
      destination       = route_rules.value.network_entity_key == "service_gateway" ? data.oci_core_services.oracle_services.services[0].cidr_block : route_rules.value.destination
      destination_type  = route_rules.value.destination_type
      network_entity_id = local.gateway_ids[route_rules.value.network_entity_key]
    }
  }
}

resource "oci_core_security_list" "security_lists" {
  for_each = var.security_lists

  compartment_id = var.compartment_id
  vcn_id         = oci_core_vcn.network.id
  display_name   = each.value.display_name
  freeform_tags  = each.value.freeform_tags

  dynamic "ingress_security_rules" {
    for_each = each.value.ingress_rules

    content {
      protocol    = ingress_security_rules.value.protocol
      source      = ingress_security_rules.value.source
      source_type = ingress_security_rules.value.source_type
      description = ingress_security_rules.value.description
      stateless   = ingress_security_rules.value.stateless

      dynamic "tcp_options" {
        for_each = ingress_security_rules.value.tcp_min == null ? [] : [ingress_security_rules.value]

        content {
          min = tcp_options.value.tcp_min
          max = tcp_options.value.tcp_max
        }
      }
    }
  }

  dynamic "egress_security_rules" {
    for_each = each.value.egress_rules

    content {
      protocol         = egress_security_rules.value.protocol
      destination      = egress_security_rules.value.destination
      destination_type = egress_security_rules.value.destination_type
      description      = egress_security_rules.value.description
      stateless        = egress_security_rules.value.stateless

      dynamic "tcp_options" {
        for_each = egress_security_rules.value.tcp_min == null ? [] : [egress_security_rules.value]

        content {
          min = tcp_options.value.tcp_min
          max = tcp_options.value.tcp_max
        }
      }
    }
  }
}

resource "oci_core_subnet" "subnets" {
  for_each = var.subnets

  compartment_id             = var.compartment_id
  vcn_id                     = oci_core_vcn.network.id
  cidr_block                 = each.value.cidr_block
  display_name               = each.value.display_name
  dns_label                  = each.value.dns_label
  prohibit_public_ip_on_vnic = !each.value.is_public
  route_table_id             = oci_core_route_table.route_tables[each.value.route_table_key].id
  security_list_ids          = [for key in each.value.security_list_keys : oci_core_security_list.security_lists[key].id]
  freeform_tags              = each.value.freeform_tags
}
