variable "compartment_id" {
  description = "Loggingリソースを作成するコンパートメントOCID。"
  type        = string
}

variable "log_group_name" {
  description = "Log Groupの表示名。"
  type        = string
}

variable "log_group_description" {
  description = "Log Groupの説明。"
  type        = string
}

variable "freeform_tags" {
  description = "Log Groupと各Logに設定する共通フリーフォーム・タグ。"
  type        = map(string)
  default     = {}
}

variable "service_logs" {
  description = "論理キーごとのOCIサービス・ログ設定。"
  type = map(object({
    display_name  = string
    service       = string
    category      = string
    resource_id   = string
  }))
  default = {}
}
