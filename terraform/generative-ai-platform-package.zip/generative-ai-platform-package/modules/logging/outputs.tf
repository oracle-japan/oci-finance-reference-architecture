output "log_group_id" {
  description = "作成したLog GroupのOCID。"
  value       = oci_logging_log_group.service_logs.id
}

output "log_ids" {
  description = "論理キーごとのサービス・ログOCID。"
  value       = { for key, log in oci_logging_log.service_logs : key => log.id }
}
