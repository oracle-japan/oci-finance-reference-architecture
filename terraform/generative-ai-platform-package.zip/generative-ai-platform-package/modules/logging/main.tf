# サービス・ログを格納する共通Log Group
resource "oci_logging_log_group" "service_logs" {
  compartment_id = var.compartment_id
  display_name   = var.log_group_name
  description    = var.log_group_description
  freeform_tags  = var.freeform_tags
}

# ルート・モジュールから渡されたOCIサービス・ログを作成します。
resource "oci_logging_log" "service_logs" {
  for_each = var.service_logs

  display_name       = each.value.display_name
  log_group_id       = oci_logging_log_group.service_logs.id
  log_type           = "SERVICE"
  is_enabled         = true
  retention_duration = 30

  configuration {
    compartment_id = var.compartment_id

    source {
      category    = each.value.category
      resource    = each.value.resource_id
      service     = each.value.service
      source_type = "OCISERVICE"
    }
  }
}
