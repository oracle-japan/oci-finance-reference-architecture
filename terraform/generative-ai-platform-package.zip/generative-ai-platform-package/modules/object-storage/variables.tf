variable "compartment_id" {
  description = "Object Storageリソースを作成するコンパートメントOCID。"
  type        = string
}

variable "default_kms_key_id" {
  description = "Bucketごとの指定がない場合に使用するKMS Key OCID。nullの場合はOracle管理キーを使用します。"
  type        = string
  default     = null
  nullable    = true
}

variable "buckets" {
  description = "論理キーごとのObject Storage Bucket設定。"
  type = map(object({
    name                  = string
    access_type           = optional(string, "NoPublicAccess")
    auto_tiering          = optional(string, "Disabled")
    object_events_enabled = optional(bool, false)
    storage_tier          = optional(string, "Standard")
    versioning            = optional(string, "Disabled")
    kms_key_id            = optional(string)
    defined_tags          = optional(map(string))
    freeform_tags         = optional(map(string), {})
  }))
  default = {}

  validation {
    condition = alltrue([
      for bucket in values(var.buckets) :
      contains(["NoPublicAccess", "ObjectRead", "ObjectReadWithoutList"], bucket.access_type)
    ])
    error_message = "access_typeには有効なObject Storage公開設定を指定してください。"
  }

  validation {
    condition = alltrue([
      for bucket in values(var.buckets) :
      contains(["Disabled", "InfrequentAccess"], bucket.auto_tiering)
    ])
    error_message = "auto_tieringはDisabledまたはInfrequentAccessを指定してください。"
  }

  validation {
    condition = alltrue([
      for bucket in values(var.buckets) :
      contains(["Standard", "Archive"], bucket.storage_tier)
    ])
    error_message = "storage_tierはStandardまたはArchiveを指定してください。"
  }

  validation {
    condition = alltrue([
      for bucket in values(var.buckets) :
      bucket.storage_tier != "Archive" || bucket.auto_tiering == "Disabled"
    ])
    error_message = "Archive Bucketではauto_tieringをDisabledにしてください。"
  }

  validation {
    condition = alltrue([
      for bucket in values(var.buckets) :
      contains(["Enabled", "Suspended", "Disabled"], bucket.versioning)
    ])
    error_message = "versioningにはEnabled、Suspended、Disabledのいずれかを指定してください。"
  }
}
