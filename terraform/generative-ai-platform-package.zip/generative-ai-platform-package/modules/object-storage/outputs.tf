output "namespace" {
  description = "テナンシのObject Storage Namespace。"
  value       = data.oci_objectstorage_namespace.object_storage.namespace
}

output "bucket_ids" {
  description = "論理キーごとのBucket OCID。"
  value       = { for key, bucket in oci_objectstorage_bucket.buckets : key => bucket.bucket_id }
}

output "bucket_names" {
  description = "論理キーごとのBucket名。"
  value       = { for key, bucket in oci_objectstorage_bucket.buckets : key => bucket.name }
}
