# テナンシのObject Storage Namespaceを取得します。
data "oci_objectstorage_namespace" "object_storage" {
  compartment_id = var.compartment_id
}

# ルート・モジュールから渡された用途別Bucketを作成します。
resource "oci_objectstorage_bucket" "buckets" {
  for_each = var.buckets

  compartment_id        = var.compartment_id
  namespace             = data.oci_objectstorage_namespace.object_storage.namespace
  name                  = each.value.name
  access_type           = each.value.access_type
  auto_tiering          = each.value.auto_tiering
  object_events_enabled = each.value.object_events_enabled
  storage_tier          = each.value.storage_tier
  versioning            = each.value.versioning
  kms_key_id            = each.value.kms_key_id != null ? each.value.kms_key_id : var.default_kms_key_id
  defined_tags          = each.value.defined_tags
  freeform_tags         = each.value.freeform_tags
}
