# 共通Autonomous Database Moduleで公開アクセスのLakehouseを作成します。
module "autonomous_database" {
  source = "../modules/autonomous-database"

  compartment_id = var.compartment_ocid
  databases      = local.autonomous_databases
}
