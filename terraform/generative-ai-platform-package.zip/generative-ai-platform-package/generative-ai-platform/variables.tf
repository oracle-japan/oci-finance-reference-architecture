# 基本設定
variable "tenancy_ocid" {
  description = "テナンシーOCID。Resource Managerにより自動設定されます。"
  type        = string
}

variable "compartment_ocid" {
  description = "リソースを作成するコンパートメントOCID。"
  type        = string
}

variable "region" {
  description = "リソースのデプロイ先として使用するOCIリージョンを指定します。"
  type        = string
}

variable "iam_domain_name" {
  description = "使用するIAMアイデンティティ・ドメイン表示名。"
  type        = string
  default     = "Default"
}

variable "project_name" {
  description = "リソース名に使用するプロジェクト名。"
  type        = string
  default     = "financial-genai"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,29}$", var.project_name))
    error_message = "英小文字で始まる 3～30 文字の英小文字、数字、ハイフンで指定してください。"
  }
}

variable "freeform_tags" {
  description = "全リソースに追加するフリーフォーム・タグ。"
  type        = map(string)
  default     = {}
}

# ネットワーク
variable "vcn_cidr" {
  description = "VCNの /16 IPv4 CIDR。"
  type        = string
  default     = "10.0.0.0/16"

  validation {
    condition     = can(cidrnetmask(var.vcn_cidr)) && endswith(var.vcn_cidr, "/16")
    error_message = "有効な /16 IPv4 CIDRを指定してください。"
  }
}

/*
variable "allowed_ingress_cidr" {
  description = "プライベートLoad BalancerとAPI Gatewayへの接続元CIDR。"
  type        = string
  default     = "10.0.0.0/16"

  validation {
    condition     = can(cidrnetmask(var.allowed_ingress_cidr))
    error_message = "有効なIPv4 CIDRを指定してください。"
  }
}
*/

# アプリケーション
variable "container_image" {
  description = "フロントエンドContainer Instanceが使用する同一リージョンOCIRイメージURL。"
  type        = string
  nullable    = false

  validation {
    condition     = trimspace(var.container_image) != ""
    error_message = "Container Instanceが使用するOCIRイメージURLを指定してください。"
  }
}

variable "service_function_image" {
  description = "Functions SubnetのFunctionが使用する同一リージョンOCIRイメージURL。"
  type        = string
  nullable    = false

  validation {
    condition     = trimspace(var.service_function_image) != ""
    error_message = "Functions SubnetのFunctionが使用するOCIRイメージURLを指定してください。"
  }
}

variable "backend_api_function_image" {
  description = "Backend API SubnetのFunctionが使用する同一リージョンOCIRイメージURL。"
  type        = string
  nullable    = false

  validation {
    condition     = trimspace(var.backend_api_function_image) != ""
    error_message = "Backend API SubnetのFunctionが使用するOCIRイメージURLを指定してください。"
  }
}

variable "enable_iam_resources" {
  description = "IAM Domain動的リソース・グループと実行時Policyを作成します。"
  type        = bool
  default     = true
}
