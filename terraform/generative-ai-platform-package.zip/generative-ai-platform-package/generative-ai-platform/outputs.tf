output "vcn_id" {
  description = "VCNのOCID。"
  value       = module.network.vcn_id
}

output "iam_domain" {
  description = "選択したIAM Domain。"
  value = {
    id           = local.iam_domain.id
    display_name = local.iam_domain.display_name
    url          = local.iam_domain.url
  }
}

output "frontend_url" {
  description = "プライベート生成AIフロントエンドURL。"
  value       = "http://${oci_load_balancer_load_balancer.frontend.ip_address_details[0].ip_address}"
}

output "api_endpoint" {
  description = "プライベートAPI Gateway Deploymentエンドポイント。"
  value       = oci_apigateway_deployment.backend_api.endpoint
}

output "bucket_name" {
  description = "生成AIバケット名。"
  value       = module.object_storage.bucket_names["genaibucket"]
}

output "function_endpoints" {
  description = "Functionsの呼出しエンドポイント。"
  value       = { for key, function in oci_functions_function.service_functions : key => function.invoke_endpoint }
}

output "lakehouse_id" {
  description = "Autonomous AI DatabaseのOCID。"
  value       = module.autonomous_database.database_ids["lakehouse"]
}

output "genai_agent_endpoint_id" {
  description = "Generative AI Agent EndpointのOCID。"
  value       = oci_generative_ai_agent_agent_endpoint.financial_assistant.id
}

output "deployment_notes" {
  description = "運用上の注意。"
  value = [
    "フロントエンドとAPIの利用にはVCN、VPN、FastConnectなどのプライベート接続が必要です。"
  ]
}
