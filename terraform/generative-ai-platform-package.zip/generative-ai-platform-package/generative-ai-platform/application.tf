# Load Balancerと共用するフロントエンド・サブネットに配置します。
resource "oci_container_instances_container_instance" "frontend" {
  availability_domain      = data.oci_identity_availability_domains.region.availability_domains[0].name
  compartment_id           = var.compartment_ocid
  display_name             = "${local.name_prefix}-frontend"
  shape                    = "CI.Standard.E4.Flex"
  container_restart_policy = "ALWAYS"
  freeform_tags            = local.common_tags

  shape_config {
    ocpus         = 1
    memory_in_gbs = 16
  }

  containers {
    display_name = "frontend"
    image_url    = var.container_image

    health_checks {
      health_check_type        = "HTTP"
      name                     = "frontend-http"
      path                     = "/"
      port                     = local.container_port
    }
  }

  vnics {
    subnet_id             = module.network.subnet_ids["frontend"]
    display_name          = "frontend-vnic"
    is_public_ip_assigned = false
  }
}

data "oci_core_vnic" "frontend" {
  vnic_id = oci_container_instances_container_instance.frontend.vnics[0].vnic_id
}

# Container Instanceと同じフロントエンド・サブネットに配置します。
resource "oci_load_balancer_load_balancer" "frontend" {
  compartment_id             = var.compartment_ocid
  display_name               = "${local.name_prefix}-lb"
  shape                      = "flexible"
  subnet_ids                 = [module.network.subnet_ids["frontend"]]
  is_private                 = true
  freeform_tags              = local.common_tags

  shape_details {
    minimum_bandwidth_in_mbps = local.load_balancer_min_bandwidth_mbps
    maximum_bandwidth_in_mbps = local.load_balancer_max_bandwidth_mbps
  }
}

resource "oci_load_balancer_backend_set" "frontend_pool" {
  load_balancer_id = oci_load_balancer_load_balancer.frontend.id
  name             = "frontend"
  policy           = "ROUND_ROBIN"

  health_checker {
    protocol          = "HTTP"
    port              = local.container_port
  }
}

resource "oci_load_balancer_backend" "frontend_container" {
  load_balancer_id = oci_load_balancer_load_balancer.frontend.id
  backendset_name  = oci_load_balancer_backend_set.frontend_pool.name
  ip_address       = data.oci_core_vnic.frontend.private_ip_address
  port             = local.container_port
  weight           = 1
}

resource "oci_load_balancer_listener" "frontend_http" {
  load_balancer_id         = oci_load_balancer_load_balancer.frontend.id
  name                     = "http"
  default_backend_set_name = oci_load_balancer_backend_set.frontend_pool.name
  port                     = local.container_port
  protocol                 = "HTTP"

  connection_configuration {
    idle_timeout_in_seconds = 60
  }
}

# 用途ごとにフロー図のサブネットへFunctions Applicationを配置します。
# 入力するOCIRイメージがx86 単一アーキテクチャのため、Applicationもx86 に固定します。
resource "oci_functions_application" "service_applications" {
  for_each = {
    service = {
      subnet_id = module.network.subnet_ids["functions"]
    }
    api = {
      subnet_id = module.network.subnet_ids["backend_api"]
    }
  }

  compartment_id             = var.compartment_ocid
  display_name               = "${local.name_prefix}-${each.key}-app"
  subnet_ids                 = [each.value.subnet_id]
  shape                      = "GENERIC_X86"
  freeform_tags              = local.common_tags

  config = {
    OCI_REGION       = var.region
    OCI_COMPARTMENT  = var.compartment_ocid
    IAM_DOMAIN_ID    = local.iam_domain.id
    OBJECT_NAMESPACE = module.object_storage.namespace
    BUCKET_NAME      = module.object_storage.bucket_names["genaibucket"]
  }

  trace_config {
    is_enabled = false
  }
}

resource "oci_functions_function" "service_functions" {
  for_each = local.function_definitions

  application_id     = oci_functions_application.service_applications[each.value.application].id
  display_name       = "${local.name_prefix}-${each.key}"
  image              = each.value.image
  memory_in_mbs      = 512
  timeout_in_seconds = 120
  freeform_tags      = local.common_tags

  trace_config {
    is_enabled = false
  }
}

resource "oci_apigateway_gateway" "backend_api" {
  compartment_id             = var.compartment_ocid
  endpoint_type              = "PRIVATE"
  subnet_id                  = module.network.subnet_ids["backend_api"]
  display_name               = "${local.name_prefix}-api-gateway"
  freeform_tags              = local.common_tags
}

resource "oci_apigateway_deployment" "backend_api" {
  compartment_id = var.compartment_ocid
  gateway_id     = oci_apigateway_gateway.backend_api.id
  display_name   = "${local.name_prefix}-api"
  path_prefix    = "/genai"
  freeform_tags  = local.common_tags

  specification {
    routes {
      path    = "/{request*}"
      methods = ["GET", "POST", "OPTIONS"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.service_functions["api"].id
      }
    }
  }

  depends_on = [oci_identity_policy.service_access]
}

# 提供リージョンを確認して明示的に有効化します。
resource "oci_generative_ai_agent_agent" "financial_assistant" {
  compartment_id  = var.compartment_ocid
  display_name    = "${local.name_prefix}-agent"
  description     = "金融サービス向け生成AI Agent"
  welcome_message = "金融サービスに関するご質問を入力してください。"
  freeform_tags   = local.common_tags

  # Agentのモデル利用権限を先に反映します。
  depends_on = [oci_identity_policy.service_access]

  llm_config {
    routing_llm_customization {
      llm_selection {
        llm_selection_type = "DEFAULT"
      }
    }
  }
}

resource "oci_generative_ai_agent_agent_endpoint" "financial_assistant" {
  compartment_id               = var.compartment_ocid
  agent_id                     = oci_generative_ai_agent_agent.financial_assistant.id
  display_name                 = "${local.name_prefix}-agent-endpoint"
  should_enable_session        = true
  should_enable_trace          = true
  should_enable_multi_language = true
  should_enable_citation       = false
  freeform_tags                = local.common_tags

  content_moderation_config {
    should_enable_on_input  = true
    should_enable_on_output = true
  }

  session_config {
    # OCI APIが許可する最小値は 3,600 秒です。
    idle_timeout_in_seconds = 3600
  }
}
