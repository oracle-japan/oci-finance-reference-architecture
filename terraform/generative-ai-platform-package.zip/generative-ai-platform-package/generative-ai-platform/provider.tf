# Resource Managerでは認証情報が自動的に提供されます。
provider "oci" {
  region = var.region
}

# IAM Policyはテナンシのホーム・リージョンで管理します。
provider "oci" {
  alias  = "home"
  region = local.home_region
}
