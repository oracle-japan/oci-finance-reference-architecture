locals {
  name_prefix             = var.project_name
  iam_domain              = try(data.oci_identity_domains.selected.domains[0], null)
  oci_region_names_by_key = { for region in data.oci_identity_regions.available.regions : region.key => region.name }
  home_region             = lookup(local.oci_region_names_by_key, data.oci_identity_tenancy.current.home_region_key)

  common_tags = merge(var.freeform_tags, {
    Project      = var.project_name
    Architecture = "generative-ai-platform"
    ManagedBy    = "Resource Manager"
  })

  object_storage_buckets = {
    genaibucket = {
      name                  = "${local.name_prefix}-genaibucket"
      object_events_enabled = true
      freeform_tags         = local.common_tags
    }
  }

  autonomous_databases = {
    lakehouse = {
      db_name       = "GENAILAKE"
      display_name  = "${local.name_prefix}-lakehouse"
      db_workload   = "LH"
      freeform_tags = local.common_tags
    }
  }

  route_tables = {
    internal_services = {
      display_name  = "${local.name_prefix}-private-rt"
      freeform_tags = local.common_tags
      route_rules = [
        {
          destination_type   = "SERVICE_CIDR_BLOCK"
          network_entity_key = "service_gateway"
        }
      ]
    }
  }

  security_lists = {
    internal_services = {
      display_name  = "${local.name_prefix}-private-sl"
      freeform_tags = local.common_tags
      ingress_rules = [
        {
          protocol    = "all"
          source      = var.vcn_cidr
          description = "VCN内部の全プロトコル"
        }
      ]
      egress_rules = [
        {
          protocol    = "all"
          destination = "0.0.0.0/0"
        }
      ]
    }
  }

  # サブネットはRoute TableとSecurity Listを論理キーで参照します。
  subnets = {
    frontend = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 10)
      display_name       = "pri-${local.name_prefix}-frontend-subnet"
      dns_label          = "frontend"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.common_tags
    }
    backend_api = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 20)
      display_name       = "pri-${local.name_prefix}-backend-api-subnet"
      dns_label          = "backendapi"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.common_tags
    }
    functions = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 30)
      display_name       = "pri-${local.name_prefix}-functions-subnet"
      dns_label          = "functions"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.common_tags
    }
  }

  function_definitions = {
    service = {
      application = "service"
      image       = var.service_function_image
    }
    api = {
      application = "api"
      image       = var.backend_api_function_image
    }
  }

  load_balancer_min_bandwidth_mbps = 10
  load_balancer_max_bandwidth_mbps = 100
  container_port                   = 80
}
