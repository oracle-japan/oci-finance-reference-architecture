# 共通Object Storage Moduleでアプリケーション用Bucketを作成します。
module "object_storage" {
  source = "../modules/object-storage"

  compartment_id = var.compartment_ocid
  buckets         = local.object_storage_buckets
}
