# 共通Logging ModuleにFunctionsとAPI Gatewayのサービス・ログ設定を渡します。
module "logging" {
  source = "../modules/logging"

  compartment_id        = var.compartment_ocid
  log_group_name        = "${local.name_prefix}-logs"
  log_group_description = "生成AIアーキテクチャのサービス・ログ"
  freeform_tags          = local.common_tags
  service_logs           = merge(
    {
      for key, application in oci_functions_application.service_applications :
      "function_${key}" => {
        display_name = "${key}-invoke-log"
        service      = "functions"
        category     = "invoke"
        resource_id  = application.id
      }
    },
    {
      backend_api_access = {
        display_name = "api-access-log"
        service      = "apigateway"
        category     = "access"
        resource_id  = oci_apigateway_deployment.backend_api.id
      }
    }
  )
}

# Monitoringは各OCIサービスが提供する標準メトリックを使用します。
