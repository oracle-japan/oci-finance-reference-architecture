# 選択したIAM Domainにリソース・プリンシパルを定義します。
resource "oci_identity_domains_dynamic_resource_group" "service_functions" {
  count = var.enable_iam_resources ? 1 : 0

  display_name  = "${local.name_prefix}-functions-drg"
  description   = "生成AI Functionsのリソース・プリンシパル"
  idcs_endpoint = local.iam_domain.url
  matching_rule = "ALL {resource.type = 'fnfunc', resource.compartment.id = '${var.compartment_ocid}'}"
  schemas       = ["urn:ietf:params:scim:schemas:oracle:idcs:DynamicResourceGroup"]
}

resource "oci_identity_domains_dynamic_resource_group" "financial_assistant" {
  count = var.enable_iam_resources ? 1 : 0

  display_name  = "${local.name_prefix}-agent-drg"
  description   = "Generative AI Agentのリソース・プリンシパル"
  idcs_endpoint = local.iam_domain.url
  matching_rule = "ALL {resource.type = 'genaiagent', resource.compartment.id = '${var.compartment_ocid}'}"
  schemas       = ["urn:ietf:params:scim:schemas:oracle:idcs:DynamicResourceGroup"]
}

# Dynamic GroupはOCI OCIDで参照します。
resource "oci_identity_policy" "service_access" {
  count = var.enable_iam_resources ? 1 : 0

  provider = oci.home

  compartment_id = var.compartment_ocid
  name           = "${replace(local.name_prefix, "-", "_")}_runtime_policy"
  description    = "生成AIアーキテクチャの実行時IAM Policy"
  freeform_tags  = local.common_tags

  statements = [
    "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.service_functions[0].ocid} to manage objects in compartment id ${var.compartment_ocid}",
    "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.service_functions[0].ocid} to read buckets in compartment id ${var.compartment_ocid}",
    "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.service_functions[0].ocid} to use generative-ai-family in compartment id ${var.compartment_ocid}",
    "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.service_functions[0].ocid} to manage ai-service-speech-family in compartment id ${var.compartment_ocid}",
    "Allow any-user to use functions-family in compartment id ${var.compartment_ocid} where all {request.principal.type='ApiGateway', request.resource.compartment.id='${var.compartment_ocid}'}",
    "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.financial_assistant[0].ocid} to use generative-ai-chat in compartment id ${var.compartment_ocid}",
    "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.financial_assistant[0].ocid} to read generative-ai-model in compartment id ${var.compartment_ocid}",
    "Allow any-user to use generative-ai-family in compartment id ${var.compartment_ocid} where any {request.principal.type='genaiagent'}"
  ]
}
