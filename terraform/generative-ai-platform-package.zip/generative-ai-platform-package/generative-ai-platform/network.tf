# 共通Network Moduleに生成AIアーキテクチャの設定を渡します。
module "network" {
  source = "../modules/network"

  compartment_id = var.compartment_ocid
  vcn = {
    cidr_blocks   = [var.vcn_cidr]
    display_name  = "${local.name_prefix}-vcn"
    dns_label     = "genaivcn"
    freeform_tags = local.common_tags
  }
  service_gateway = {
    display_name  = "${local.name_prefix}-service-gateway"
    freeform_tags = local.common_tags
  }

  route_tables   = local.route_tables
  security_lists = local.security_lists
  subnets        = local.subnets
}
