# OCI Generative AI Platform Terraform

## Terraform サンプルコードについて

本ディレクトリに含まれるTerraformコードは、本リファレンスアーキテクチャで示す構成や考え方を理解するための参考実装（サンプルコード）です。

本コードは、特定のお客様環境や本番環境へのそのままの適用を目的として設計されたものではありません。また、本コードのみを根拠としてシステム設計を行うことを意図したものでもありません。

実際のシステムを設計・構築する際には、対象環境の要件に応じて、以下を含む各種要件を個別に検討してください。

* セキュリティおよびアクセス制御
* 可用性、冗長性および災害対策
* 性能およびスケーラビリティ
* ネットワーク構成
* 運用、監視およびバックアップ
* コストおよびリソースサイジング
* 組織のセキュリティポリシー、ガバナンスおよびコンプライアンス要件
* 利用するサービス、Terraform Providerおよび各種依存コンポーネントのバージョン

本コードを利用する場合は、内容を十分に確認し、利用環境に合わせて必要な変更を行ったうえで、事前に適切なレビューおよび検証を実施してください。

## Disclaimer

本資料およびTerraformコードは、情報提供および参考目的で提供されるものです。特定のシステム構成、設計、性能、セキュリティ、可用性または運用結果を保証するものではありません。

実際のシステムへの適用可否および構成については、各利用者の責任において、要件、環境、適用される規則・ポリシー等を考慮したうえで判断してください。

また、クラウドサービス、Terraform Providerその他関連する製品・サービスの仕様は変更される場合があります。利用時には、各製品・サービスの最新の公式ドキュメントおよびサポートされる構成を確認してください。

## 本コードについて

OCI 上に金融機関向けの生成AI活用基盤を構築する Terraform 構成です。

この README では、Terraform の構造、設定の流れ、事前に定義する変数、`terraform.tfvars` で編集する値について説明します。

## 構造

```text
generative-ai-platform-package/
├── modules/
│   ├── autonomous-database/
│   ├── logging/
│   ├── network/
│   └── object-storage/
└── generative-ai-platform/
    ├── application.tf
    ├── data.tf
    ├── database.tf
    ├── locals.tf
    ├── network.tf
    ├── observability.tf
    ├── outputs.tf
    ├── provider.tf
    ├── schema.yaml
    ├── security.tf
    ├── storage.tf
    ├── terraform.tfvars.example
    ├── variables.tf
    └── versions.tf
```

Terraform の実行ディレクトリは `generative-ai-platform/` です。

主な構成は以下です。

* `network.tf`
  VCN、Subnet、Service Gateway などのネットワークを作成します。
* `application.tf`
  Container Instance、Load Balancer、OCI Functions、API Gateway、Generative AI Agent を作成します。
* `database.tf`
  Autonomous AI Database を作成します。
* `storage.tf`
  生成AIアプリケーションで利用する Object Storage Bucket を作成します。
* `security.tf`
  IAM Dynamic Resource Group と実行時 Policy を設定します。
* `observability.tf`
  Functions、API Gateway の Logging を設定します。

## 設定の流れ

### 1. サンプル設定をコピー

```bash
cd generative-ai-platform-package/generative-ai-platform
cp terraform.tfvars.example terraform.tfvars
```

### 2. `terraform.tfvars` を編集

OCI 環境に合わせて基本設定を変更します。

```hcl
tenancy_ocid     = "ocid1.tenancy.oc1..xxxxxxxx"
compartment_ocid = "ocid1.compartment.oc1..xxxxxxxx"
region           = "ap-osaka-1"
iam_domain_name  = "Default"

project_name = "financial-genai"

vcn_cidr = "10.0.0.0/16"
```

あわせて、Container Instance および OCI Functions で使用する OCIR イメージを指定します。

```hcl
container_image            = "<region-key>.ocir.io/<tenancy-namespace>/<repository-path>:<tag>"
service_function_image     = "<region-key>.ocir.io/<tenancy-namespace>/<repository-path>:<tag>"
backend_api_function_image = "<region-key>.ocir.io/<tenancy-namespace>/<repository-path>:<tag>"
```

IAM Resource を Terraform で作成する場合は以下を指定します。

```hcl
enable_iam_resources = true
```

### 3. Terraform を初期化

```bash
terraform init
```

### 4. 設定を確認

```bash
terraform validate
terraform plan
```

### 5. リソースを作成

```bash
terraform apply
```

## 事前に定義する変数

### 必須

| 変数                           | 説明                                      | 例                                      |
| ---------------------------- | --------------------------------------- | -------------------------------------- |
| `tenancy_ocid`               | OCI Tenancy の OCID                      | `ocid1.tenancy.oc1..xxxx`              |
| `compartment_ocid`           | 作成先 Compartment の OCID                  | `ocid1.compartment.oc1..xxxx`          |
| `region`                     | デプロイ先 Region                            | `ap-osaka-1`                           |
| `container_image`            | Frontend Container Instance 用 OCIR イメージ | `kix.ocir.io/namespace/repository:tag` |
| `service_function_image`     | Service Function 用 OCIR イメージ            | `kix.ocir.io/namespace/repository:tag` |
| `backend_api_function_image` | Backend API Function 用 OCIR イメージ        | `kix.ocir.io/namespace/repository:tag` |

OCIR イメージは、デプロイ先の OCI 環境からアクセス可能なイメージを指定してください。

### 基本設定

| 変数                | 説明                    | デフォルト / 例         |
| ----------------- | --------------------- | ----------------- |
| `iam_domain_name` | IAM Identity Domain 名 | `Default`         |
| `project_name`    | リソース名の Prefix         | `financial-genai` |
| `vcn_cidr`        | VCN CIDR              | `10.0.0.0/16`     |
| `freeform_tags`   | 追加する Free-form Tags   | `{}`              |

### IAM

Terraform で IAM Resource を作成する場合:

```hcl
enable_iam_resources = true
iam_domain_name      = "Default"
```

既存の IAM 設定を利用する場合:

```hcl
enable_iam_resources = false
```

## 編集するサンプル値

`terraform.tfvars.example` をコピー後、以下を環境に合わせて編集してください。

```hcl
tenancy_ocid     = "YOUR_TENANCY_OCID"
compartment_ocid = "YOUR_COMPARTMENT_OCID"
region           = "ap-osaka-1"
iam_domain_name  = "Default"

project_name = "financial-genai"

vcn_cidr = "10.0.0.0/16"

container_image            = "<region-key>.ocir.io/<tenancy-namespace>/<repository-path>:<tag>"
service_function_image     = "<region-key>.ocir.io/<tenancy-namespace>/<repository-path>:<tag>"
backend_api_function_image = "<region-key>.ocir.io/<tenancy-namespace>/<repository-path>:<tag>"

enable_iam_resources = true
```

最低限、環境に合わせて確認・変更する値は以下です。

```hcl
tenancy_ocid
compartment_ocid
region
container_image
service_function_image
backend_api_function_image
```

Resource Manager を利用する場合、`tenancy_ocid` は Resource Manager により自動設定されます。

また、フロントエンドおよび API はプライベート構成のため、利用する際は VCN、VPN、FastConnect などから接続できるネットワーク環境が必要です。
