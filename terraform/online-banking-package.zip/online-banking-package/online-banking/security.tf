# 共通KMS Moduleで既存Vaultの再利用と暗号化キー作成を管理します。
module "kms" {
  source = "../modules/kms"

  enabled            = var.enable_kms
  compartment_id     = var.compartment_ocid
  existing_vault_id  = var.existing_vault_id
  vault_display_name = "${local.name_prefix}-vault"
  key_display_name   = "${local.name_prefix}-master-key"
  freeform_tags      = local.architecture_stack_tags.core
}

# Functionsのリソース・プリンシパル
resource "oci_identity_domains_dynamic_resource_group" "banking_functions" {
  count = var.enable_iam_resources ? 1 : 0

  display_name  = "${local.name_prefix}-functions-drg"
  description   = "オンライン・バンキングFunctionsのリソース・プリンシパル"
  idcs_endpoint = local.iam_domain.url
  matching_rule = "ALL {resource.type = 'fnfunc', resource.compartment.id = '${var.compartment_ocid}'}"
  schemas       = ["urn:ietf:params:scim:schemas:oracle:idcs:DynamicResourceGroup"]
}

# Resource SchedulerにOutbox Processor Functionの実行権限を付与します。
resource "oci_identity_domains_dynamic_resource_group" "outbox_scheduler" {
  count = var.enable_iam_resources ? 1 : 0

  display_name  = "${local.name_prefix}-outbox-scheduler-drg"
  description   = "Outbox Processorを実行するResource Scheduler"
  idcs_endpoint = local.iam_domain.url
  matching_rule = "ALL {resource.type = 'resourceschedule', resource.id = '${oci_resource_scheduler_schedule.outbox_processor.id}'}"
  schemas       = ["urn:ietf:params:scim:schemas:oracle:idcs:DynamicResourceGroup"]
}

# Dynamic GroupはOCI OCIDで参照します。
resource "oci_identity_policy" "service_access" {
  count = var.enable_iam_resources ? 1 : 0

  provider = oci.home

  compartment_id = var.compartment_ocid
  name           = "${replace(local.name_prefix, "-", "_")}_runtime_policy"
  description    = "オンライン・バンキングの実行時IAM Policy"
  freeform_tags  = local.common_tags

  statements = concat(
    [
      "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.banking_functions[0].ocid} to manage objects in compartment id ${var.compartment_ocid}",
      "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.banking_functions[0].ocid} to read buckets in compartment id ${var.compartment_ocid}",
      "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.banking_functions[0].ocid} to use stream-push in compartment id ${var.compartment_ocid}",
      "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.banking_functions[0].ocid} to use stream-pull in compartment id ${var.compartment_ocid}"
    ],
    [
      "Allow any-user to use functions-family in compartment id ${var.compartment_ocid} where all {request.principal.type='ApiGateway', request.resource.compartment.id='${var.compartment_ocid}'}"
    ],
    [
      "Allow any-user to {STREAM_READ, STREAM_CONSUME} in compartment id ${var.compartment_ocid} where all {request.principal.type='serviceconnector', target.stream.id='${oci_streaming_stream.banking_events.id}', request.principal.compartment.id='${var.compartment_ocid}'}",
      "Allow any-user to use fn-function in compartment id ${var.compartment_ocid} where all {request.principal.type='serviceconnector', request.principal.compartment.id='${var.compartment_ocid}'}",
      "Allow any-user to use fn-invocation in compartment id ${var.compartment_ocid} where all {request.principal.type='serviceconnector', request.principal.compartment.id='${var.compartment_ocid}'}"
    ],
    [
      "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.outbox_scheduler[0].ocid} to use fn-function in compartment id ${var.compartment_ocid}",
      "Allow dynamic-group id ${oci_identity_domains_dynamic_resource_group.outbox_scheduler[0].ocid} to use fn-invocation in compartment id ${var.compartment_ocid}"
    ],
    var.enable_kms ? [
      "Allow service objectstorage-${var.region} to use keys in compartment id ${var.compartment_ocid}"
    ] : []
  )
}
