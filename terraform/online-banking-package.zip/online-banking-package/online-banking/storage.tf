# 共通Object Storage ModuleでReactアプリ用Bucketを作成します。
module "object_storage" {
  source = "../modules/object-storage"

  compartment_id     = var.compartment_ocid
  default_kms_key_id = module.kms.key_id
  buckets            = local.object_storage_buckets
}

# Reactアプリの配置確認に使用するデモ・ページをアップロードします。
resource "oci_objectstorage_object" "frontend_index" {
  namespace = module.object_storage.namespace
  bucket    = module.object_storage.bucket_names["frontend"]
  object    = "index.html"
  source    = "${path.module}/assets/index.html"

  content_type  = "text/html; charset=utf-8"
  cache_control = "public, max-age=300"
}
