# Mobile/Core Functions Application
resource "oci_functions_application" "banking_applications" {
  for_each = local.function_applications

  compartment_id = var.compartment_ocid
  display_name   = "${local.name_prefix}-${each.key}-app"
  subnet_ids = [
    module.network.subnet_ids[each.value.subnet]
  ]
  shape         = "GENERIC_X86"
  freeform_tags = each.value.freeform_tags
}

resource "oci_functions_function" "banking_functions" {
  for_each = local.function_definitions

  application_id     = oci_functions_application.banking_applications[each.value.application].id
  display_name       = "${local.name_prefix}-${replace(each.key, "_", "-")}"
  image              = each.value.image
  memory_in_mbs      = 512
  timeout_in_seconds = 120
  freeform_tags      = local.function_applications[each.value.application].freeform_tags
}

# Mobile Banking公開API
resource "oci_apigateway_gateway" "mobile_api" {
  compartment_id             = var.compartment_ocid
  endpoint_type              = "PUBLIC"
  subnet_id                  = module.network.subnet_ids["mobile_api"]
  display_name               = "${local.name_prefix}-mobile-api-gateway"
  freeform_tags              = local.architecture_stack_tags.backend
}

resource "oci_apigateway_deployment" "mobile_api" {
  compartment_id = var.compartment_ocid
  gateway_id     = oci_apigateway_gateway.mobile_api.id
  display_name   = "${local.name_prefix}-mobile-api"
  path_prefix    = "/api"
  freeform_tags  = local.architecture_stack_tags.backend

  specification {
    routes {
      path    = "/accounts"
      methods = ["POST"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.banking_functions["account_opening"].id
      }
    }

    routes {
      path    = "/transfers"
      methods = ["POST"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.banking_functions["transfer"].id
      }
    }
  }
}

# Core Banking非公開API
resource "oci_apigateway_gateway" "core_api" {
  compartment_id             = var.compartment_ocid
  endpoint_type              = "PRIVATE"
  subnet_id                  = module.network.subnet_ids["core_api"]
  display_name               = "${local.name_prefix}-core-api-gateway"
  freeform_tags              = local.architecture_stack_tags.core
}

resource "oci_apigateway_deployment" "core_api" {
  compartment_id = var.compartment_ocid
  gateway_id     = oci_apigateway_gateway.core_api.id
  display_name   = "${local.name_prefix}-core-api"
  path_prefix    = "/core"
  freeform_tags  = local.architecture_stack_tags.core

  specification {
    routes {
      path    = "/{request*}"
      methods = ["GET", "POST", "PUT", "DELETE"]

      backend {
        type        = "ORACLE_FUNCTIONS_BACKEND"
        function_id = oci_functions_function.banking_functions["core_banking"].id
      }
    }
  }
}
