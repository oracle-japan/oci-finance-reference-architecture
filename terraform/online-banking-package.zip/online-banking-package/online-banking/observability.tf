# 共通Logging ModuleにFunctionsとAPI Gatewayのサービス・ログ設定を渡します。
module "logging" {
  source = "../modules/logging"

  compartment_id        = var.compartment_ocid
  log_group_name        = "${local.name_prefix}-logs"
  log_group_description = "オンライン・バンキングのサービス・ログ"
  freeform_tags          = local.common_tags
  service_logs           = merge(
    {
      for key, application in oci_functions_application.banking_applications :
      "function_${key}" => {
        display_name  = "${key}-invoke-log"
        service       = "functions"
        category      = "invoke"
        resource_id   = application.id
        freeform_tags = local.architecture_stack_tags[key == "mobile" ? "backend" : "core"]
      }
    },
    {
      mobile_api_access = {
        display_name  = "mobile-api-access-log"
        service       = "apigateway"
        category      = "access"
        resource_id   = oci_apigateway_deployment.mobile_api.id
        freeform_tags = local.architecture_stack_tags.backend
      }
      core_api_access = {
        display_name  = "core-api-access-log"
        service       = "apigateway"
        category      = "access"
        resource_id   = oci_apigateway_deployment.core_api.id
        freeform_tags = local.architecture_stack_tags.core
      }
    }
  )
}

# Monitoringは各OCIサービスが提供する標準メトリックを使用します。
# AuditはOCIで常時有効なため作成リソースはありません。
