# Outbox Processorが発行するオンライン・バンキング・イベント
resource "oci_streaming_stream_pool" "banking_events" {
  compartment_id = var.compartment_ocid
  name           = "${local.name_prefix}-stream-pool"
  freeform_tags  = local.architecture_stack_tags.backend

  kafka_settings {
    auto_create_topics_enable = false
    log_retention_hours       = 24
    num_partitions            = local.stream_partitions
  }
}

resource "oci_streaming_stream" "banking_events" {
  name               = "banking-events"
  partitions         = local.stream_partitions
  retention_in_hours = 24
  stream_pool_id     = oci_streaming_stream_pool.banking_events.id
  freeform_tags      = local.architecture_stack_tags.backend
}

# Outbox Processor FunctionをResource Schedulerから定期実行します。
resource "oci_resource_scheduler_schedule" "outbox_processor" {
  action             = "START_RESOURCE"
  compartment_id     = var.compartment_ocid
  recurrence_details = local.outbox_processor_cron
  recurrence_type    = "CRON"
  display_name       = "${local.name_prefix}-outbox-processor"
  description        = "Outbox TableをポーリングしてStreamingへイベントを発行"
  state              = "ACTIVE"
  freeform_tags      = local.architecture_stack_tags.backend

  resources {
    id = oci_functions_function.banking_functions["outbox_processor"].id
  }
}

# Streamingのイベントをコア・バンキング処理Functionへ配信します。
resource "oci_sch_service_connector" "banking_events_to_core" {
  compartment_id = var.compartment_ocid
  display_name   = "${local.name_prefix}-banking-events"
  description    = "Streamingからコア・バンキング処理Functionへのイベント配信"
  freeform_tags  = local.architecture_stack_tags.backend

  source {
    kind      = "streaming"
    stream_id = oci_streaming_stream.banking_events.id

    cursor {
      kind = "LATEST"
    }
  }

  target {
    kind        = "functions"
    function_id = oci_functions_function.banking_functions["core_banking"].id
  }
}
