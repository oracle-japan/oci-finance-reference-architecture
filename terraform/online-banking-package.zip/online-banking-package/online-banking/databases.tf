# 共通Autonomous Database ModuleでBackend/CoreのOLTPを 1 台ずつ作成します。
module "autonomous_database" {
  source = "../modules/autonomous-database"

  compartment_id = var.compartment_ocid
  databases = {
    for key, database in local.autonomous_databases : key => {
      db_name       = database.db_name
      display_name  = "${local.name_prefix}-${replace(key, "_", "-")}"
      db_workload   = "OLTP"
      subnet_id     = module.network.subnet_ids[database.subnet]
      freeform_tags = database.freeform_tags      
    }
  }
}
