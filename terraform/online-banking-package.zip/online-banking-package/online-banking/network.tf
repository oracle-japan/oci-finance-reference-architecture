# 共通Network Moduleにオンライン・バンキングの設定を渡します。
module "network" {
  source = "../modules/network"

  compartment_id = var.compartment_ocid
  vcn = {
    cidr_blocks   = [var.vcn_cidr]
    display_name  = "${local.name_prefix}-vcn"
    dns_label     = "onlinebankvcn"
    freeform_tags = local.common_tags
  }
  internet_gateway = {
    display_name  = "${local.name_prefix}-igw"
    enabled       = true
    freeform_tags = local.architecture_stack_tags.backend
  }
  service_gateway = {
    display_name  = "${local.name_prefix}-service-gateway"
    freeform_tags = local.common_tags
  }

  route_tables   = local.route_tables
  security_lists = local.security_lists
  subnets        = local.subnets
}
