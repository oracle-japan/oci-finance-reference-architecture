# 基本設定
variable "tenancy_ocid" {
  description = "テナンシーOCID。Resource Managerにより自動設定されます。"
  type        = string
}

variable "compartment_ocid" {
  description = "リソースを作成するコンパートメントOCID。"
  type        = string
}

variable "region" {
  description = "リソースのデプロイ先として使用するOCIリージョンを指定します。"
  type        = string
}

variable "iam_domain_name" {
  description = "使用するIAMアイデンティティ・ドメイン表示名。"
  type        = string
  default     = "Default"
}

variable "project_name" {
  description = "リソース名に使用するプロジェクト名。"
  type        = string
  default     = "online-banking"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,29}$", var.project_name))
    error_message = "英小文字で始まる 3～30 文字の英小文字、数字、ハイフンで指定してください。"
  }
}

variable "freeform_tags" {
  description = "全リソースに追加するフリーフォーム・タグ。"
  type        = map(string)
  default     = {}
}

# ネットワーク
variable "vcn_cidr" {
  description = "VCNの /16 IPv4 CIDR。"
  type        = string
  default     = "10.0.0.0/16"

  validation {
    condition     = can(cidrnetmask(var.vcn_cidr)) && endswith(var.vcn_cidr, "/16")
    error_message = "有効な /16 IPv4 CIDRを指定してください。"
  }
}

# フロントエンドWAF/CDN
variable "enable_waf" {
  description = "WAAS WAF/CDN Policyを作成します。"
  type        = bool
  default     = false
}

variable "frontend_domain_name" {
  description = "WAF/CDNで保護するフロントエンドFQDN。"
  type        = string
  default     = ""

  validation {
    condition = var.frontend_domain_name == "" || can(regex(
      "^([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?\\.)+[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?$",
      trimspace(var.frontend_domain_name)
    ))
    error_message = "frontend_domain_nameはbanking.example.comのようなFQDNで指定してください。"
  }
}

variable "dns_zone_name" {
  description = "フロントエンドFQDNの親となるパブリックDNS Zone名。"
  type        = string
  default     = ""

  validation {
    condition = var.dns_zone_name == "" || can(regex(
      "^([A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?\\.)+[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?$",
      trimspace(var.dns_zone_name)
    ))
    error_message = "dns_zone_nameはexample.comのようなPublic DNS Zone名で指定してください。"
  }
}

# IAMおよび暗号化
variable "enable_iam_resources" {
  description = "IAM Domain動的リソース・グループと実行時Policyを作成します。"
  type        = bool
  default     = true
}

variable "enable_kms" {
  description = "Vaultと暗号化キーを使用します。"
  type        = bool
  default     = false
}

variable "existing_vault_id" {
  description = "再利用する既存Vault OCID。空の場合は新しいVaultを作成します。"
  type        = string
  default     = ""

  validation {
    condition     = var.existing_vault_id == "" || startswith(var.existing_vault_id, "ocid1.vault.")
    error_message = "existing_vault_idにはVault OCID、または空文字を指定してください。"
  }
}
