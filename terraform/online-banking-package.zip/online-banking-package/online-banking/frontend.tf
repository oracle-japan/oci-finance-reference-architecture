# WAASはWAFとエッジ・キャッシュを提供します。
resource "oci_waas_waas_policy" "frontend" {
  count = var.enable_waf && var.frontend_domain_name != "" ? 1 : 0

  compartment_id = var.compartment_ocid
  domain         = var.frontend_domain_name
  display_name   = "${local.name_prefix}-frontend-waas"
  freeform_tags  = local.architecture_stack_tags.frontend

  origins {
    label      = "frontend"
    uri        = "${module.object_storage.namespace}.compat.objectstorage.${var.region}.oci.customer-oci.com"
    # WAAS WAF構成では非ゼロのHTTP Origin Portが必須です。
    http_port  = 80
    https_port = 443
  }

  policy_config {
    # 前段CDNが設定するX-Forwarded-Forからクライアント・アドレスを取得します。
    client_address_header         = "X_FORWARDED_FOR"
    is_behind_cdn                 = true

    load_balancing_method {
      method = "ROUND_ROBIN"
    }
  }

  # WAFが転送するオリジンを明示します。
  waf_config {
    origin = "frontend"
  }
}

# 同一コンパートメントに既存のPublic DNS Zoneがある場合は再利用します。
data "oci_dns_zones" "frontend" {
  count = var.dns_zone_name != "" ? 1 : 0

  compartment_id = var.compartment_ocid
  name           = var.dns_zone_name
  scope          = "GLOBAL"
  zone_type      = "PRIMARY"
}

# 指定名のZoneが存在せず、既存Zone OCIDも未指定の場合のみ作成します。
resource "oci_dns_zone" "frontend" {
  count = var.dns_zone_name != "" && try(length(data.oci_dns_zones.frontend[0].zones), 0) == 0 ? 1 : 0

  compartment_id = var.compartment_ocid
  name           = var.dns_zone_name
  zone_type      = "PRIMARY"
  scope          = "GLOBAL"
  freeform_tags  = local.architecture_stack_tags.frontend
}

resource "oci_dns_rrset" "frontend_waas" {
  count = var.dns_zone_name != "" && length(oci_waas_waas_policy.frontend) > 0 ? 1 : 0

  zone_name_or_id = try(data.oci_dns_zones.frontend[0].zones[0].id, oci_dns_zone.frontend[0].id)
  domain          = var.frontend_domain_name
  rtype           = "CNAME"

  items {
    domain = var.frontend_domain_name
    rdata  = oci_waas_waas_policy.frontend[0].cname
    rtype  = "CNAME"
    ttl    = 300
  }

  lifecycle {
    precondition {
      condition = endswith(
        lower(trimsuffix(var.frontend_domain_name, ".")),
        ".${lower(trimsuffix(var.dns_zone_name, "."))}"
      )
      error_message = "フロントエンドFQDNはDNS Zone配下のCNAME名として指定してください。Zone apexにはCNAMEを作成できません。"
    }
  }
}
