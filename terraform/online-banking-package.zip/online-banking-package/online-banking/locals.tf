locals {
  name_prefix             = var.project_name
  iam_domain              = try(data.oci_identity_domains.selected.domains[0], null)
  oci_region_names_by_key = { for region in data.oci_identity_regions.available.regions : region.key => region.name }
  home_region             = lookup(local.oci_region_names_by_key, data.oci_identity_tenancy.current.home_region_key)

  # 非同期処理は常時有効とし、内部既定値を使用します。
  outbox_processor_cron = "0 * * * *"
  stream_partitions     = 1

  common_tags = merge(var.freeform_tags, {
    Project      = var.project_name
    Architecture = "OnlineBanking"
    ManagedBy    = "Resource Manager"
  })

  # 構成図の論理スタックを全リソースのタグで識別します。
  architecture_stack_names = {
    frontend = "OnlineBankingAppFrontendStack"
    backend  = "OnlineBankingAppBackendStack"
    core     = "TemporaryCoreBankingSystemStack"
  }

  architecture_stack_tags = {
    for key, name in local.architecture_stack_names :
    key => merge(local.common_tags, { ArchitectureStack = name })
  }

  object_storage_buckets = {
    frontend = {
      name = "${local.name_prefix}-frontend"
      # 静的ファイルの取得のみを公開し、Bucket一覧の参照は許可しません。
      access_type   = "ObjectReadWithoutList"
      freeform_tags = local.architecture_stack_tags.frontend
    }
  }

  route_tables = {
    internet_access = {
      display_name  = "${local.name_prefix}-public-rt"
      freeform_tags = local.architecture_stack_tags.backend
      route_rules = [
        {
          destination        = "0.0.0.0/0"
          destination_type   = "CIDR_BLOCK"
          network_entity_key = "internet_gateway"
        }
      ]
    }
    internal_services = {
      display_name  = "${local.name_prefix}-private-rt"
      freeform_tags = local.common_tags
      route_rules = [
        {
          destination_type   = "SERVICE_CIDR_BLOCK"
          network_entity_key = "service_gateway"
        }
      ]
    }
  }

  security_lists = {
    internet_facing = {
      display_name  = "${local.name_prefix}-public-sl"
      freeform_tags = local.architecture_stack_tags.backend
      ingress_rules = [
        {
          protocol = "6"
          source   = "0.0.0.0/0"
          tcp_min  = 443
          tcp_max  = 443
        }
      ]
      egress_rules = [
        {
          protocol    = "all"
          destination = "0.0.0.0/0"
        }
      ]
    }
    internal_services = {
      display_name  = "${local.name_prefix}-private-sl"
      freeform_tags = local.common_tags
      ingress_rules = [
        {
          protocol    = "all"
          source      = var.vcn_cidr
          description = "VCN内部の全プロトコル"
        }
      ]
      egress_rules = [
        {
          protocol    = "all"
          destination = "0.0.0.0/0"
        }
      ]
    }
  }

  # 公開／非公開サブネットを同じ形式で定義し、関連リソースを論理キーで参照します。
  subnets = {
    mobile_api = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 10)
      display_name       = "pub-${local.name_prefix}-backend-mobile-api-subnet"
      dns_label          = "pubmobileapi"
      is_public          = true
      route_table_key    = "internet_access"
      security_list_keys = ["internet_facing"]
      freeform_tags      = local.architecture_stack_tags.backend
    }
    backend_functions = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 20)
      display_name       = "pri-${local.name_prefix}-backend-functions-subnet"
      dns_label          = "backendfn"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.architecture_stack_tags.backend
    }
    backend_database = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 30)
      display_name       = "pri-${local.name_prefix}-backend-database-subnet"
      dns_label          = "backenddb"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.architecture_stack_tags.backend
    }
    core_api = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 40)
      display_name       = "pri-${local.name_prefix}-core-api-subnet"
      dns_label          = "coreapi"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.architecture_stack_tags.core
    }
    core_functions = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 50)
      display_name       = "pri-${local.name_prefix}-core-functions-subnet"
      dns_label          = "corefn"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.architecture_stack_tags.core
    }
    core_database = {
      cidr_block         = cidrsubnet(var.vcn_cidr, 8, 60)
      display_name       = "pri-${local.name_prefix}-core-database-subnet"
      dns_label          = "coredb"
      is_public          = false
      route_table_key    = "internal_services"
      security_list_keys = ["internal_services"]
      freeform_tags      = local.architecture_stack_tags.core
    }
  }

  # 各Functionは大阪リージョンのOCIRにある個別Image Tagを使用します。
  function_image_repository = "kix.ocir.io/sehubjapacprod/oci-financial-architecture-demo"

  function_applications = {
    mobile = {
      subnet        = "backend_functions"
      freeform_tags = local.architecture_stack_tags.backend
    }
    core = {
      subnet        = "core_functions"
      freeform_tags = local.architecture_stack_tags.core
    }
  }

  function_definitions = {
    transfer = {
      application = "mobile"
      # 振込処理関数用イメージ
      image       = "${local.function_image_repository}:hello-0.0.1"
    }
    account_opening = {
      application = "mobile"
      # 口座開設処理関数用イメージ
      image       = "${local.function_image_repository}:hello-0.0.1"
    }
    outbox_processor = {
      application = "mobile"
      # アウトボックス処理関数用イメージ
      image       = "${local.function_image_repository}:hello-0.0.1"
    }
    core_banking = {
      application = "core"
      # バックエンド処理関数用イメージ
      image       = "${local.function_image_repository}:hello-0.0.1"
    }
  }

  # Event Store／Outboxと顧客／取引マスターを、それぞれ 1 台のOLTP ADBに集約します。
  autonomous_databases = {
    backend = {
      db_name       = "BANKAPP"
      subnet        = "backend_database"
      freeform_tags = local.architecture_stack_tags.backend
    }
    temporary_core = {
      db_name       = "COREBANK"
      subnet        = "core_database"
      freeform_tags = local.architecture_stack_tags.core
    }
  }
}
