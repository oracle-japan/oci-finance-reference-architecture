data "oci_identity_regions" "available" {}

data "oci_identity_tenancy" "current" {
  tenancy_id = var.tenancy_ocid
}

data "oci_identity_domains" "selected" {
  compartment_id = var.tenancy_ocid
  display_name    = var.iam_domain_name
  state           = "ACTIVE"
}
