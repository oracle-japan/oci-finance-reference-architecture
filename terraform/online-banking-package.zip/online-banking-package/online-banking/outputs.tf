output "vcn_id" {
  description = "VCNのOCID。"
  value       = module.network.vcn_id
}

output "iam_domain" {
  description = "選択したIAM Domain。"
  value = {
    id           = local.iam_domain.id
    display_name = local.iam_domain.display_name
    url          = local.iam_domain.url
  }
}

output "frontend_bucket_name" {
  description = "Reactアプリ用バケット名。"
  value       = module.object_storage.bucket_names["frontend"]
}

output "mobile_api_endpoint" {
  description = "Mobile Banking APIエンドポイント。"
  value       = oci_apigateway_deployment.mobile_api.endpoint
}

output "core_api_endpoint" {
  description = "Core Banking APIエンドポイント。"
  value       = oci_apigateway_deployment.core_api.endpoint
}

output "function_endpoints" {
  description = "Functionsの呼出しエンドポイント。"
  value       = { for key, function in oci_functions_function.banking_functions : key => function.invoke_endpoint }
}

output "autonomous_database_ids" {
  description = "Backend/Coreの 2 個のOLTP Autonomous Database OCID。"
  value       = module.autonomous_database.database_ids
}

output "stream_id" {
  description = "バンキング・イベントStream OCID。"
  value       = oci_streaming_stream.banking_events.id
}

output "outbox_scheduler_id" {
  description = "Outbox Processor Resource SchedulerのOCID。"
  value       = oci_resource_scheduler_schedule.outbox_processor.id
}

output "waas_cname" {
  description = "DNSに設定するWAAS CNAME。"
  value       = try(oci_waas_waas_policy.frontend[0].cname, null)
}

output "kms_key_id" {
  description = "暗号化キーOCID。"
  value       = module.kms.key_id
}

output "kms_vault_id" {
  description = "再利用または新規作成したVault OCID。"
  value       = module.kms.vault_id
}

output "deployment_notes" {
  description = "未作成リソースと運用上の注意。"
  value = compact([
    var.enable_waf && var.frontend_domain_name == "" ? "WAAS作成にはフロントエンドFQDNが必要です。" : ""
  ])
}
