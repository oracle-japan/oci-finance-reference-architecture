variable "enabled" {
  description = "Vaultと暗号化キーを使用するかどうか。"
  type        = bool
  default     = true
}

variable "compartment_id" {
  description = "Vaultと暗号化キーを配置するコンパートメントOCID。"
  type        = string
}

variable "existing_vault_id" {
  description = "再利用する既存Vault OCID。空の場合は新しいVaultを作成します。"
  type        = string
  default     = ""

  validation {
    condition     = var.existing_vault_id == "" || startswith(var.existing_vault_id, "ocid1.vault.")
    error_message = "existing_vault_idにはVault OCID、または空文字を指定してください。"
  }
}

variable "vault_display_name" {
  description = "新規作成するVaultの表示名。"
  type        = string
}

variable "vault_type" {
  description = "新規作成するVaultのタイプ。"
  type        = string
  default     = "DEFAULT"

  validation {
    condition     = contains(["DEFAULT", "VIRTUAL_PRIVATE"], var.vault_type)
    error_message = "vault_typeはDEFAULTまたはVIRTUAL_PRIVATEを指定してください。"
  }
}

variable "key_display_name" {
  description = "作成する暗号化キーの表示名。"
  type        = string
}

variable "key_protection_mode" {
  description = "暗号化キーの保護モード。"
  type        = string
  default     = "HSM"

  validation {
    condition     = contains(["HSM", "SOFTWARE"], var.key_protection_mode)
    error_message = "key_protection_modeはHSMまたはSOFTWAREを指定してください。"
  }
}

variable "freeform_tags" {
  description = "Vaultと暗号化キーに設定するフリーフォーム・タグ。"
  type        = map(string)
  default     = {}
}
