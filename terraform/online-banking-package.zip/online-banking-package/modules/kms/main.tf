# 指定された既存Vaultの管理エンドポイントを取得します。
data "oci_kms_vault" "existing" {
  count = var.enabled && trimspace(var.existing_vault_id) != "" ? 1 : 0

  vault_id = var.existing_vault_id
}

# 既存Vaultが指定されていない場合のみ新しいVaultを作成します。
resource "oci_kms_vault" "encryption" {
  count = var.enabled && trimspace(var.existing_vault_id) == "" ? 1 : 0

  compartment_id = var.compartment_id
  display_name    = var.vault_display_name
  vault_type      = var.vault_type
  freeform_tags   = var.freeform_tags
}

locals {
  vault_id = var.enabled ? try(
    data.oci_kms_vault.existing[0].id,
    oci_kms_vault.encryption[0].id
  ) : null

  management_endpoint = var.enabled ? try(
    data.oci_kms_vault.existing[0].management_endpoint,
    oci_kms_vault.encryption[0].management_endpoint
  ) : null
}

# 選択または作成したVaultに暗号化キーを作成します。
resource "oci_kms_key" "encryption" {
  count = var.enabled ? 1 : 0

  compartment_id      = var.compartment_id
  display_name        = var.key_display_name
  management_endpoint = local.management_endpoint
  protection_mode     = var.key_protection_mode
  freeform_tags       = var.freeform_tags

  key_shape {
    algorithm = "AES"
    length    = 32
  }
}
