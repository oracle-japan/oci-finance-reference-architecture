output "vault_id" {
  description = "再利用または新規作成したVault OCID。"
  value       = local.vault_id
}

output "management_endpoint" {
  description = "Vaultの管理エンドポイント。"
  value       = local.management_endpoint
}

output "key_id" {
  description = "作成した暗号化キーOCID。"
  value       = try(oci_kms_key.encryption[0].id, null)
}
