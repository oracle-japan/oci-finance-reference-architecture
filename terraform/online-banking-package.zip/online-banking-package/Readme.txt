# OCI Online Banking Terraform

## Terraform サンプルコードについて

本ディレクトリに含まれるTerraformコードは、本リファレンスアーキテクチャで示す構成や考え方を理解するための参考実装（サンプルコード）です。

本コードは、特定のお客様環境や本番環境へのそのままの適用を目的として設計されたものではありません。また、本コードのみを根拠としてシステム設計を行うことを意図したものでもありません。

実際のシステムを設計・構築する際には、対象環境の要件に応じて、以下を含む各種要件を個別に検討してください。

* セキュリティおよびアクセス制御
* 可用性、冗長性および災害対策
* 性能およびスケーラビリティ
* ネットワーク構成
* 運用、監視およびバックアップ
* コストおよびリソースサイジング
* 組織のセキュリティポリシー、ガバナンスおよびコンプライアンス要件
* 利用するサービス、Terraform Providerおよび各種依存コンポーネントのバージョン

本コードを利用する場合は、内容を十分に確認し、利用環境に合わせて必要な変更を行ったうえで、事前に適切なレビューおよび検証を実施してください。

## Disclaimer

本資料およびTerraformコードは、情報提供および参考目的で提供されるものです。特定のシステム構成、設計、性能、セキュリティ、可用性または運用結果を保証するものではありません。

実際のシステムへの適用可否および構成については、各利用者の責任において、要件、環境、適用される規則・ポリシー等を考慮したうえで判断してください。

また、クラウドサービス、Terraform Providerその他関連する製品・サービスの仕様は変更される場合があります。利用時には、各製品・サービスの最新の公式ドキュメントおよびサポートされる構成を確認してください。

## 本コードについて

OCI 上にオンラインバンキング向けの環境を構築する Terraform 構成です。

この README では、Terraform の構造、設定の流れ、事前に定義する変数、`terraform.tfvars` で編集する値だけを説明します。

## 構造

```text
online-banking-package/
├── modules/
│   ├── autonomous-database/
│   ├── kms/
│   ├── logging/
│   ├── network/
│   └── object-storage/
└── online-banking/
    ├── application.tf
    ├── databases.tf
    ├── frontend.tf
    ├── messaging.tf
    ├── network.tf
    ├── observability.tf
    ├── security.tf
    ├── storage.tf
    ├── provider.tf
    ├── variables.tf
    ├── outputs.tf
    ├── terraform.tfvars.example
    └── schema.yaml
```

Terraform の実行ディレクトリは `online-banking/` です。

主な構成は以下です。

* `network.tf`
  VCN、Subnet、Internet Gateway、Service Gateway などを作成します。
* `application.tf`
  API Gateway と OCI Functions を作成します。
* `databases.tf`
  Backend 用、Core Banking 用の Autonomous Database を作成します。
* `messaging.tf`
  OCI Streaming、Service Connector Hub、Scheduler を作成します。
* `frontend.tf` / `storage.tf`
  フロントエンド用 Object Storage と、必要に応じて WAF / DNS を作成します。
* `security.tf`
  IAM、Dynamic Group、KMS / Vault を設定します。
* `observability.tf`
  Functions、API Gateway の Logging を設定します。

## 設定の流れ

### 1. サンプル設定をコピー

```bash
cd online-banking-package/online-banking
cp terraform.tfvars.example terraform.tfvars
```

### 2. `terraform.tfvars` を編集

最低限、以下を OCI 環境に合わせて変更します。

```hcl
tenancy_ocid     = "ocid1.tenancy.oc1..xxxxxxxx"
compartment_ocid = "ocid1.compartment.oc1..xxxxxxxx"
region           = "ap-osaka-1"

iam_domain_name = "Default"
project_name     = "online-banking"
vcn_cidr         = "10.0.0.0/16"
```

必要に応じて WAF、DNS、IAM、KMS を設定します。

```hcl
enable_waf           = false
frontend_domain_name = ""
dns_zone_name        = ""

enable_iam_resources = true

enable_kms        = false
existing_vault_id = ""
```

### 3. Terraform を初期化

```bash
terraform init
```

### 4. 設定を確認

```bash
terraform validate
terraform plan
```

### 5. リソースを作成

```bash
terraform apply
```

## 事前に定義する変数

### 必須

| 変数                 | 説明                     | 例                             |
| ------------------ | ---------------------- | ----------------------------- |
| `tenancy_ocid`     | OCI Tenancy の OCID     | `ocid1.tenancy.oc1..xxxx`     |
| `compartment_ocid` | 作成先 Compartment の OCID | `ocid1.compartment.oc1..xxxx` |
| `region`           | デプロイ先 Region           | `ap-osaka-1`                  |

### 基本設定

| 変数                | 説明                    | デフォルト / 例        |
| ----------------- | --------------------- | ---------------- |
| `iam_domain_name` | IAM Identity Domain 名 | `Default`        |
| `project_name`    | リソース名の Prefix         | `online-banking` |
| `vcn_cidr`        | VCN CIDR              | `10.0.0.0/16`    |
| `freeform_tags`   | 追加する Free-form Tags   | `{}`             |

### WAF / DNS

WAF と独自ドメインを利用する場合に設定します。

```hcl
enable_waf           = true
frontend_domain_name = "bank.example.com"
dns_zone_name        = "example.com"
```

利用しない場合:

```hcl
enable_waf           = false
frontend_domain_name = ""
dns_zone_name        = ""
```

### IAM

Terraform で IAM Resource を作成する場合:

```hcl
enable_iam_resources = true
iam_domain_name      = "Default"
```

既存の IAM 設定を利用する場合:

```hcl
enable_iam_resources = false
```

### KMS

Oracle 管理キーを利用する場合:

```hcl
enable_kms = false
```

Vault / KMS Key を新規作成する場合:

```hcl
enable_kms        = true
existing_vault_id = ""
```

既存 Vault を利用する場合:

```hcl
enable_kms        = true
existing_vault_id = "ocid1.vault.oc1.ap-osaka-1.xxxxxxxx"
```

## 編集するサンプル値

`terraform.tfvars.example` をコピー後、以下を環境に合わせて編集してください。

```hcl
tenancy_ocid     = "YOUR_TENANCY_OCID"
compartment_ocid = "YOUR_COMPARTMENT_OCID"
region           = "ap-osaka-1"

iam_domain_name = "Default"
project_name     = "online-banking"
vcn_cidr         = "10.0.0.0/16"

enable_waf           = false
frontend_domain_name = ""
dns_zone_name        = ""

enable_iam_resources = true

enable_kms        = false
existing_vault_id = ""
```

最低限変更が必要なのは以下です。

```hcl
tenancy_ocid
compartment_ocid
region
```

WAF、独自ドメイン、KMS を使用する場合のみ、対応する値を追加で変更します。
